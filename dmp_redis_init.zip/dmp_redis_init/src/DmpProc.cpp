#include "DmpProc.h"

CDmpProc::CDmpProc():m_pRedis(NULL)
{
	SRedis sRedis;
	LoadRedisConfig(sRedis);
	InitRedis(sRedis);
	InitInterest();
}

CDmpProc::~CDmpProc()
{
	delete m_pRedis;
	m_pRedis = NULL;
}

void CDmpProc::LoadRedisConfig(SRedis& sRedis)
{
	stringstream s; 
	ConfigReader cf;
	std::map<string, string>::iterator itr;
	std::map<string, string> mRedis = cf("./config/DmpProc.conf", true);
	if((itr = mRedis.find("redis_ip")) != mRedis.end())
	{
		sRedis.ip = itr->second;
	}
	if((itr = mRedis.find("redis_port")) != mRedis.end())
	{
		sRedis.port = atoi(itr->second.c_str());
	}
	if((itr = mRedis.find("redis_timeout")) != mRedis.end())
	{
		sRedis.timeout = atoi(itr->second.c_str());
	}
	if((itr = mRedis.find("redis_conn")) != mRedis.end())
	{
		sRedis.connum = atoi(itr->second.c_str());
	}
	if((itr = mRedis.find("nodes")) != mRedis.end())
	{
		std::cout<<" nodes: "<<itr->second<<std::endl;
		m_pRedis =  new r3c::CRedisClient(itr->second);
	}
	//s<<"LoadRedisParam\tip:"<<sRedis.ip<<"\tport:"<<sRedis.port<<"\ttimeout: "<<sRedis.timeout<<"\tconnum:"<<sRedis.connum;
	//log(INFO, s.str());
}

void CDmpProc::InitRedis(SRedis& sRedis)
{

	if (!m_redisClient.Initialize(sRedis.ip,sRedis.port, sRedis.timeout, sRedis.connum))
	{
		stringstream s;
		s<<" init redis fail ret: ";
		log(LOG_ERROR, s.str());	
	}
}


bool CDmpProc::GetDmp(const std::string& deviceId, SInterest& sInterest)
{
	std::string key = "", field = "", val = "", sep = "|";
	unsigned long  nDeviceid =   BKDRHash(deviceId.c_str());
	std::stringstream sd;
	sd<<nDeviceid;
	std::string id = sd.str(),  ekey = "", efield = "";
	if(!SplitKey(id,  key, field, 8, 7))//8位开始, 7bit作为key.
	{
		return false;
	}
	ekey = key;
	Encode(field, efield);
	try
	{
		if (!m_pRedis->hget(ekey, efield, &val))
		{
			//ERROR_PRINT("%s", "NOT EXISTS");
			std::cout<< "GetDmp\t"<<key<<"\t field: "<<field<<"\t val: "<< val<<"\t not exist";
			return false;
		}
	}catch (r3c::CRedisException& ex)
	{
		std::cout<< "GetDmp\t"<<key<<"\t field: "<<field<<"\t"<<ex.str();
	}
	std::vector<std::string> vIdx, vInterestId;
	SplitSub(val, sep, &vIdx);
	if(3 != vIdx.size())
	{
		return false;
	}
	//insterest
	if(!ParseInterest(vIdx[0], vInterestId))
	{
		//return false;
	}
	sep = "\001";
	std::vector<std::string>::iterator itr;
	//std::map< std::string, std::vector<std::string> >::iterator 
	for(itr = vInterestId.begin(); itr != vInterestId.end(); itr++)
	{
        if(m_interest.find(*itr) == m_interest.end())
        {
            continue;
        }
		std::string val =m_interest[*itr];
		std::vector<std::string> vTag;
		SplitSub(val, sep, &vTag);
		if(vTag.size() < 1 )
		{
			continue;
		}
		else if(1 == vTag.size())
		{
			std::vector<std::string> v;
			sInterest.mInterest[vTag[0]] = v;
		}
		else if(2 == vTag.size())
		{
			std::map< std::string, std::vector<std::string> >::iterator itr = sInterest.mInterest.find(vTag[0]); //vtag[0] == tag1 ,  vtag[1] == tag2
			if( itr == sInterest.mInterest.end() )
			{
				std::vector<std::string> v;
				v.push_back(vTag[1]);
				sInterest.mInterest[vTag[0]] = v;
				//std::cout<<" tag1: "<<vTag[0]<<"\t tag2:"<<vTag[1];

				//std::cout<<"mIn: "<<sInterest.mInterest[0]<<std::endl;
			}
			else
			{
				sInterest.mInterest[vTag[0]].push_back(vTag[1]);
			}
		}
	}
	if("-" != vIdx[1])
		sInterest.gender =  vIdx[1];
	if("-" != vIdx[2])
		sInterest.age = atoi(vIdx[2].c_str());

	//auto atr = sInterest.mInterest.begin();
	/*std::cout<<" len; "<<sInterest.mInterest.size();
	std::map< std::string, std::vector<std::string> >::iterator itr1 = sInterest.mInterest.begin();
	for(; itr1 !=  sInterest.mInterest.end(); itr1++)
	{
	auto itrv = itr1->second.begin();
	for(; itrv != itr1->second.end(); itrv++ )
	std::cout<<" "<<itr1->first<<" "<<*itrv<<std::endl;
	}*/

	return true;
}

/*bool  CRedisClient::Encode(const std::string& deviceId, std::string& key)
{
int size = deviceId.size();
stringstream s;
for(int i = 0; i < size;)
{
int data  = atoi(deviceId.substr(i, 2).c_str());
if((data >= 0 && data <= 9) || 32 == data ||  92 == data|| 34 == data)   // ' ' '\\', "
{ 
s<<data;
}
else
{
char ch = data;
s<<ch;
}
i+=2;
}
key = s.str();
return true;
}*/


bool CDmpProc::GetDmpFromFile(const std::string& file)
{
	ifstream in(file);  
	if (!in.is_open())  
	{ 
		string str = "GetDmpFromFile open fail " + file;
		log(LOG_ERROR, str);
		return false;
	}
	std::stringstream sinfo;
	sinfo<<"get  file "<<file<<" begin";
	log(INFO, sinfo.str());

	int nRecord = 0;
	std::string lastKey = "", allField = "";


	while (!in.eof() )  
	{
		char buffer[4096] = {'\0'};
		in.getline (buffer, 4096);
		std::vector<std::string> vDmp = strsplit(buffer, "\t");
		if(3 == vDmp.size())
		{
			std::string   ret = "";
			TestR3CGetDmp(vDmp[0], vDmp[1],   ret);
		}
	}
}

bool CDmpProc::TestR3CGetDmp(const std::string& key, const std::string&  field,  std::string& ret)
{
	struct timeval time1, time2;
	gettimeofday(&time1, NULL);

	std::string ekey = "", efield = "", val = "", sep = "|";
	ekey = key;
	//Encode(key, ekey);
	Encode(field, efield);
	if(NULL == m_pRedis)
	{
		std::string str = "TestR3CGetDmp  m_pRedis is null ";
		log(LOG_ERROR, str);
		return false;
	}
	try
	{
		if (! m_pRedis->hget(ekey, efield, &val))
		{
			//ERROR_PRINT("%s", "NOT EXISTS");
			stringstream s; 
			s<< "GetDmp\t"<<key<<"\t field: "<<field<<"\t val: "<< val<<"\tfail! nRet: ";
			log(LOG_ERROR, s.str());
			return false;
		}
	}catch (r3c::CRedisException& ex)
	{
		log(LOG_ERROR, ex.str());
	}
	gettimeofday(&time2, NULL);
	double time = double((time2.tv_sec - time1.tv_sec) * 1000 + (time2.tv_usec - time1.tv_usec) / 1000.0);
	std::cout<<"\tekey: "<<ekey<<"\tfield: "<<field<<"\tval: "<<val<<"\ttime: "<<time<<std::endl;

	std::vector<std::string> vIdx, vInterestId;
	SplitSub(val, sep, &vIdx);
	if(3 != vIdx.size())
	{
		return false;
	}
	//insterest
	if(!ParseInterest(vIdx[0], vInterestId))
	{
		return false;
	}
	sep = "\001";
	Json::Value root;
	std::vector<std::string>::iterator itr;
	for(itr = vInterestId.begin(); itr != vInterestId.end(); itr++)
	{
		Json::Value item;
		std::string val =m_interest[*itr];
		std::vector<std::string> vTag;
		SplitSub(val, sep, &vTag);
		if(vTag.size() < 1 )
		{
			continue;
		}
		else if(1 == vTag.size())
		{
			item["tag1"] =  vTag[0];
		}
		else if(2 == vTag.size())
		{
			item["tag1"] =  vTag[0];
			item["tag2"] =  vTag[1];
		}
		root["interestList"].append(item);
	}
	if("-" != vIdx[1])
		root["gender"] =  vIdx[1];
	if("-" != vIdx[2])
		root["age"] = atoi(vIdx[2].c_str());
	ret =  root.toStyledString();
	return true;
}

bool CDmpProc::GetDmp(const std::string& deviceId, std::string& ret)
{
	std::string key = "", field = "", val = "", sep = "|";
	unsigned long  nDeviceid =   BKDRHash(deviceId.c_str());
	std::stringstream sd;
	sd<<nDeviceid;
	std::string id = sd.str(),  ekey = "", efield = "";
	if(!SplitKey(id,  key, field, 8, 7))//前4bit 作为key.
	{
		return false;
	}
	ekey = key;
	//Encode(key, ekey);
	Encode(field, efield);
	if (! m_pRedis->hget(ekey, efield, &val))
	{
		//ERROR_PRINT("%s", "NOT EXISTS");
		stringstream s;
		s<< "GetDmp\t"<<key<<"\t field: "<<field<<"\t val: "<< val<<"\tfail! nRet: ";
		log(LOG_ERROR, s.str());
		return false;
	}


	/*if (RC_SUCCESS != m_redisClient.Hget(ekey, efield, &val))
	{
	stringstream s; 
	s<< "GetDmp\t"<<key<<"\t"<<val<<"\tfail! nRet: ";
	log(LOG_ERROR, s.str());
	return false;
	}*/
	std::cout<<"device_id: "<<deviceId<<"\thashid: "<<id<<"\tekey: "<<ekey<<"\tefield: "<<efield<<"\tval: "<<val<<endl;
	std::vector<std::string> vIdx, vInterestId;
	SplitSub(val, sep, &vIdx);
	if(3 != vIdx.size())
	{
		return false;
	}
	//insterest
	if(!ParseInterest(vIdx[0], vInterestId))
	{
		return false;
	}
	sep = "\001";
	Json::Value root;
	std::vector<std::string>::iterator itr;
	for(itr = vInterestId.begin(); itr != vInterestId.end(); itr++)
	{
		Json::Value item;
		std::string val =m_interest[*itr];
		std::vector<std::string> vTag;
		SplitSub(val, sep, &vTag);
		if(vTag.size() < 1 )
		{
			continue;
		}
		else if(1 == vTag.size())
		{
			item["tag1"] =  vTag[0];
		}
		else if(2 == vTag.size())
		{
			item["tag1"] =  vTag[0];
			item["tag2"] =  vTag[1];
		}
		root["interestList"].append(item);
	}
	if("-" != vIdx[1])
		root["gender"] =  vIdx[1];
	if("-" != vIdx[2])
		root["age"] = atoi(vIdx[2].c_str());
	ret =  root.toStyledString();

	return true;
}

bool  CDmpProc::Encode(const std::string& deviceId, std::string& key)
{
	int size = deviceId.size();
	stringstream s;
	for(int i = 0; i < size;)
	{
		int data  = atoi(deviceId.substr(i, 2).c_str());
		if(data >= 0 && data <= 9 || 32 == data ||  92 == data|| 34 == data)   // ' ' '\\', "
		{ 
			s<<data;
		}
		else
		{
			char ch = data;
			s<<ch;
		}
		i+=2;
	}
	key = s.str();
	return true;
}

bool CDmpProc::SplitKey(const std::string& deviceId, std::string& key, std::string& field, int off,  int num)
{
	//注意修改field
	key = deviceId.substr(off, num); 
	field = deviceId.substr(0, off);
	field += deviceId.substr(off+num);
	if("" == key  || "" == field)
	{
		std::cout<<"SplitKey: deviceid too short "<<deviceId<<endl;
		return false;
	}
	return true;
}

void CDmpProc::SplitSub(std::string& s, std::string& delim,std::vector< std::string >* ret) 
{
	size_t last = 0;
	size_t index=s.find_first_of(delim,last);
	while (index!=std::string::npos) 
	{
		ret->push_back(s.substr(last,index-last));
		last=index+1;
		index=s.find_first_of(delim,last);
	}
	if (index-last>0) 
	{
		ret->push_back(s.substr(last,index-last));
	}
}

bool CDmpProc::ParseInterest(std::string& sIdx, std::vector< std::string >& ret)
{
	if("-" ==  sIdx)
	{
		return false;
	}
	ret.clear();
	int i = 0, nlen = sIdx.size();
	while(i  < nlen)
	{
		std::stringstream s;
		if( '7'<=sIdx[i] && sIdx[i]<= '9')
		{
			s<<sIdx[i];
			++i;
			if(i >= nlen)
				return false;
			else
			{
				s<<sIdx[i];
				++i;
			}
		}
		else
		{
			s<<sIdx[i];
			++i;
		}
		ret.push_back(s.str());
	}
	return true;
}

unsigned long CDmpProc::BKDRHash(const char *str)
{
	unsigned int seed = 131;  // 31 131 1313 13131 131313 etc..
	unsigned long hash = 0;
	int i = 0;
	if(NULL == str)
	{
		return 0;
	}
	while (str[i] != '\0')
	{
		hash = hash * seed + str[i];
		i++;
	}
	return hash;
}

//key, filed, value.
bool CDmpProc::SetDmp(const std::string& file)
{
	ifstream in(file);  
	if (!in.is_open())  
	{ 
		string str = "SetDmp open fail " + file;
		log(LOG_ERROR, str);
		return false;
	}
	struct timeval time3, time4;
	gettimeofday(&time3, NULL);
	std::stringstream sinfo;
	sinfo<<"set file "<<file<<" begin";
	log(INFO, sinfo.str());
	std::string lastKey = "";
	std::map<std::string, std::string> mapFv;
	while (!in.eof() )  
	{  
		char buffer[4096] = {'\0'};
		in.getline (buffer, 4096);
		std::vector<std::string> vDmp = strsplit(buffer, "\t");
		if(3 == vDmp.size())
		{
			std::string key = "", field = "", val = vDmp[2];
			key = vDmp[0];
			Encode(vDmp[1], field);
			if("" == lastKey || lastKey == key)
			{
				lastKey =  key;
				mapFv[field] = val;
			}
			else
			{
				struct timeval time1, time2;
				gettimeofday(&time1, NULL);
				int num = 0, ret = 0;
				bool bFail =  true;
				while(num < 5)
				{
					ret =  m_redisClient.Hmset(lastKey,mapFv);	
					if(RC_SUCCESS == ret)
					{
						bFail = false;
						break;
					}
					++num;
				}
				if( true == bFail)
				{
					stringstream sError;
					sError<<"Hmset\t"<<lastKey<<"\t"<<file<<"\tfail\tret: "<<ret<<"\tnum: "<<num;
					log(LOG_ERROR, sError.str());
				}
				gettimeofday(&time2, NULL);
				double time = double((time2.tv_sec - time1.tv_sec) * 1000 + (time2.tv_usec - time1.tv_usec) / 1000.0);
				std::cout<<lastKey<<"\t"<<mapFv.size()<<"\t"<<time<<"\tnum: "<<num<<endl;

				lastKey = key;
				mapFv.clear();
				mapFv[field] = val;
			}
		}
	}

	gettimeofday(&time4, NULL);
	double dtime = double((time4.tv_sec - time3.tv_sec) * 1000 + (time4.tv_usec - time3.tv_usec) / 1000.0);
	sinfo.str("");
	sinfo<<"set file "<<file<<" finish costtime\t"<<dtime;
	log(INFO, sinfo.str());
	return true;
}

bool CDmpProc::SetDmpRC(const std::string& file)
{
	ifstream in(file);  
	if (!in.is_open())  
	{ 
		string str = "SetDmp open fail " + file;
		log(LOG_ERROR, str);
		return false;
	}
	if(NULL == m_pRedis)
	{
		string str = "SetDmp m_pRedis is null " + file;
		log(LOG_ERROR, str);
		return false;
	}
	struct timeval time3, time4;
	gettimeofday(&time3, NULL);
	std::stringstream sinfo;
	sinfo<<"set file "<<file<<" begin";
	log(INFO, sinfo.str());
	std::string lastKey = "";
	std::map<std::string, std::string> mapFv;
	while (!in.eof() )  
	{  
		char buffer[4096] = {'\0'};
		in.getline (buffer, 4096);
		std::vector<std::string> vDmp = strsplit(buffer, "\t");
		if(3 == vDmp.size())
		{
			std::string key = "", field = "", val = vDmp[2];
			key = vDmp[0];
			Encode(vDmp[1], field);
			if("" == lastKey || lastKey == key)
			{
				lastKey =  key;
				mapFv[field] = val;
			}
			else
			{
				struct timeval time1, time2;
				gettimeofday(&time1, NULL);

				try 
				{
					m_pRedis->hmset(lastKey,mapFv);
				}
				catch (r3c::CRedisException& ex)
				{
					log(LOG_ERROR, ex.str());
				}
				//
				gettimeofday(&time2, NULL);
				double time = double((time2.tv_sec - time1.tv_sec) * 1000 + (time2.tv_usec - time1.tv_usec) / 1000.0);
				std::cout<<lastKey<<"\t"<<mapFv.size()<<"\t"<<time<<std::endl;

				lastKey = key;
				mapFv.clear();
				mapFv[field] = val;
			}
		}
	}
	if(lastKey != "")
	{
		int num  = 0;
		while(num < 20)
		{
			try
			{
				m_pRedis->hmset(lastKey,mapFv);
				break;
			}
			catch (r3c::CRedisException& ex)
			{
				//log(LOG_ERROR, ex.str());
			}
			++num;
		}
		if(num >= 20)
		{
			std::string str = lastKey + " set fail";
			log(LOG_ERROR, str);
		}
	}
	gettimeofday(&time4, NULL);
	double dtime = double((time4.tv_sec - time3.tv_sec) * 1000 + (time4.tv_usec - time3.tv_usec) / 1000.0);
	sinfo.str("");
	sinfo<<"set file "<<file<<" finish costtime\t"<<dtime;
	log(INFO, sinfo.str());
	return true;
}


bool CDmpProc::DeleteDmpRC(const std::string& file)
{
	ifstream in(file);  
	if (!in.is_open())  
	{ 
		string str = "SetDmp open fail " + file;
		log(LOG_ERROR, str);
		return false;
	}

	if(NULL == m_pRedis)
	{
		string str = "m_pRedis is null  " + file;
		log(LOG_ERROR, str);
		return false;
	}

	struct timeval time3, time4;
	gettimeofday(&time3, NULL);
	std::stringstream sinfo;
	sinfo<<"delete file "<<file<<" begin";
	log(INFO, sinfo.str());

	int nRecord = 0;
	std::string lastKey = "";
	std::vector<std::string> vField;

	while (!in.eof() )  
	{  
		char buffer[4096] = {'\0'};
		in.getline (buffer, 4096);
		std::vector<std::string> vDmp = strsplit(buffer, "\t");
		if(3 == vDmp.size())
		{
			std::string key = "", field = "", val = vDmp[2];
			key = vDmp[0];
			Encode(vDmp[1],  field);
			if("" == lastKey || lastKey == key)
			{
				lastKey =  key;
				vField.push_back(field);
			}
			else
			{
				struct timeval time1, time2;
				gettimeofday(&time1, NULL);
				try
				{
					m_pRedis->hmdel(lastKey, vField);
				} catch (r3c::CRedisException& ex)
				{
					log(LOG_ERROR, ex.str());
				}
				gettimeofday(&time2, NULL);
				double time = double((time2.tv_sec - time1.tv_sec) * 1000 + (time2.tv_usec - time1.tv_usec) / 1000.0);
				std::cout<<lastKey<<"\t"<<vField.size()<<"\t"<<time<<std::endl;

				lastKey = key;
				vField.clear();
				vField.push_back(field);
			}
		}
	}

	gettimeofday(&time4, NULL);
	double dtime = double((time4.tv_sec - time3.tv_sec) * 1000 + (time4.tv_usec - time3.tv_usec) / 1000.0);
	sinfo.str("");
	sinfo<<"delete  file "<<file<<" finish costtime\t"<<dtime;
	log(INFO, sinfo.str());
	return true;
}

bool CDmpProc::DeleteDmp(const std::string& file)
{
	ifstream in(file);  
	if (!in.is_open())  
	{ 
		string str = "SetDmp open fail " + file;
		log(LOG_ERROR, str);
		return false;
	}

	if(NULL == m_pRedis)
	{
		string str = "m_pRedis is null  " + file;
		log(LOG_ERROR, str);
		return false;
	}

	struct timeval time3, time4;
	gettimeofday(&time3, NULL);
	std::stringstream sinfo;
	sinfo<<"delete file "<<file<<" begin";
	log(INFO, sinfo.str());

	int nRecord = 0;
	std::string lastKey = "", allField = "";


	while (!in.eof() )  
	{  
		char buffer[4096] = {'\0'};
		in.getline (buffer, 4096);
		std::vector<std::string> vDmp = strsplit(buffer, "\t");
		if(3 == vDmp.size())
		{
			std::string key = "", field = "", val = vDmp[2];
			key = vDmp[0];
			Encode(vDmp[1], field);
			if("" == lastKey || lastKey == key)
			{
				lastKey =  key;
				if("" == allField)
				{
					allField += field;
				}
				else
				{
					allField += " "+field;
				}
				++nRecord;
			}
			else
			{
				struct timeval time1, time2;
				gettimeofday(&time1, NULL);

				int num = 0, ret = 0;
				bool bFail =  true;
				while(num < 3)
				{
					ret =  m_redisClient.Hdel(lastKey, allField);	
					if(RC_SUCCESS == ret)
					{
						bFail = false;
						break;
					}
					++num;
				}
				if( true == bFail)
				{
					stringstream sError;
					sError<<"Hdel\t"<<lastKey<<"\t"<<file<<"\tfail\tret: "<<ret<<"\tnum: "<<num;
					log(LOG_ERROR, sError.str());
				}
				gettimeofday(&time2, NULL);
				double time = double((time2.tv_sec - time1.tv_sec) * 1000 + (time2.tv_usec - time1.tv_usec) / 1000.0);
				std::cout<<lastKey<<"\t"<<nRecord<<"\t"<<time<<"\tnum: "<<num<<endl;

				lastKey = key;
				allField = field;
				nRecord = 0;
			}
		}
	}

	gettimeofday(&time4, NULL);
	double dtime = double((time4.tv_sec - time3.tv_sec) * 1000 + (time4.tv_usec - time3.tv_usec) / 1000.0);
	sinfo.str("");
	sinfo<<"delete  file "<<file<<" finish costtime\t"<<dtime;
	log(INFO, sinfo.str());
	return true;
}

void CDmpProc::InitInterest()
{
	m_interest[std::string("80")] =std::string("Wearable");
	m_interest[std::string("81")] =std::string("Art & Design");
	m_interest[std::string("82")] =std::string("Auto & Vehicles");
	m_interest[std::string("83")] =std::string("Beauty");
	m_interest[std::string("84")] =std::string("Books & Reference");
	m_interest[std::string("85")] =std::string("Business");
	m_interest[std::string("86")] =std::string("Comics");
	m_interest[std::string("87")] =std::string("Communication");

	m_interest[std::string("89")] =std::string("Dating");
	m_interest[std::string("90")] =std::string("Education");
	m_interest[std::string("91")] =std::string("Entertainment");
	m_interest[std::string("92")] =std::string("Events");

	m_interest[std::string("94")] =std::string("Finance");
	m_interest[std::string("95")] =std::string("Food & Drink");
	m_interest[std::string("96")] =std::string("Health & Fitness");
	m_interest[std::string("97")] =std::string("House & Home");
	m_interest[std::string("98")] =std::string("Libraries & Demo");
	m_interest[std::string("99")] =std::string("Lifestyle");

	m_interest[std::string("{")] =std::string("Maps & Navigation");
	m_interest[std::string("}")] =std::string("Medical");
	m_interest[std::string("[")] =std::string("Music");
	m_interest[std::string("=")] =std::string("Parenting");
	m_interest[std::string(":")] =std::string("Personalization");
	m_interest[std::string("<")] =std::string("Photography");
	m_interest[std::string(">")] =std::string("Productivity");
	m_interest[std::string("?")] =std::string("Shopping");
	m_interest[std::string(",")] =std::string("Social");
	m_interest[std::string("71")] =std::string("Sports");
	m_interest[std::string("72")] =std::string("Tools");
	m_interest[std::string("73")] =std::string("Travel");
	m_interest[std::string("74")] =std::string("Video");
	m_interest[std::string("75")] =std::string("Weather");

	m_interest[std::string("a")] =std::string("Sticker\001Animals & Nature");
	m_interest[std::string("b")] =std::string("Sticker\001Art");
	m_interest[std::string("c")] =std::string("Sticker\001Celebrations");
	m_interest[std::string("d")] =std::string("Sticker\001Celebrities");
	m_interest[std::string("e")] =std::string("Sticker\001Comics & Cartoons");
	m_interest[std::string("f")] =std::string("Sticker\001Eating & Drinking");
	m_interest[std::string("g")] =std::string("Sticker\001Emoji & Expressions");
	m_interest[std::string("h")] =std::string("Sticker\001Fashion");
	m_interest[std::string("i")] =std::string("Sticker\001Gaming");
	m_interest[std::string("j")] =std::string("Sticker\001Kids & Family");
	m_interest[std::string("k")] =std::string("Sticker\001Movies & TV");
	m_interest[std::string("l")] =std::string("Sticker\001Music");
	m_interest[std::string("m")] =std::string("Sticker\001People");
	m_interest[std::string("n")] =std::string("Sticker\001Places & Objects");
	m_interest[std::string("o")] =std::string("Sticker\001Sports & Activities");
	m_interest[std::string("88")] =std::string("Sticker\001Others");

	m_interest[std::string("p")] =std::string("Family\001Ages 5 & Under");
	m_interest[std::string("q")] =std::string("Family\001Ages 6-8");
	m_interest[std::string("r")] =std::string("Family\001Ages 9 & Up");
	m_interest[std::string("s")] =std::string("Family\001Popular Characters");
	m_interest[std::string("t")] =std::string("Family\001Action & Adventure");
	m_interest[std::string("u")] =std::string("Family\001Brain Games");
	m_interest[std::string("v")] =std::string("Family\001Creativity");
	m_interest[std::string("w")] =std::string("Family\001Education");
	m_interest[std::string("x")] =std::string("Family\001Music & Video");
	m_interest[std::string("y")] =std::string("Family\001Pretend Play");
	m_interest[std::string("93")] =std::string("Family\001Others");

	m_interest[std::string("z")] =std::string("News & Magazines\001Arts & Photography");
	m_interest[std::string("A")] =std::string("News & Magazines\001Automotive");
	m_interest[std::string("B")] =std::string("News & Magazines\001Brides & Weddings");
	m_interest[std::string("C")] =std::string("News & Magazines\001Business & Investing");
	m_interest[std::string("D")] =std::string("News & Magazines\001Children's Magazines");
	m_interest[std::string("E")] =std::string("News & Magazines\001Computers & Internet");
	m_interest[std::string("F")] =std::string("News & Magazines\001Cooking, Food & Drink");
	m_interest[std::string("G")] =std::string("News & Magazines\001Crafts & Hobbies");
	m_interest[std::string("H")] =std::string("News & Magazines\001Electronics & Audio");
	m_interest[std::string("I")] =std::string("News & Magazines\001Entertainment");
	m_interest[std::string("J")] =std::string("News & Magazines\001Fashion & Style");
	m_interest[std::string("K")] =std::string("News & Magazines\001Health, Mind & Body");
	m_interest[std::string("L")] =std::string("News & Magazines\001History");
	m_interest[std::string("M")] =std::string("News & Magazines\001Home & Garden");
	m_interest[std::string("N")] =std::string("News & Magazines\001Literary Magazines & Journals");
	m_interest[std::string("O")] =std::string("News & Magazines\001Men's Interest");
	m_interest[std::string("P")] =std::string("News & Magazines\001Movies & Music");
	m_interest[std::string("Q")] =std::string("News & Magazines\001News & Politics");
	m_interest[std::string("R")] =std::string("News & Magazines\001Outdoors & Nature");
	m_interest[std::string("S")] =std::string("News & Magazines\001Parenting & Family");
	m_interest[std::string("T")] =std::string("News & Magazines\001Pets");
	m_interest[std::string("U")] =std::string("News & Magazines\001Professional & Trade");
	m_interest[std::string("V")] =std::string("News & Magazines\001Regional News");
	m_interest[std::string("W")] =std::string("News & Magazines\001Science");
	m_interest[std::string("X")] =std::string("News & Magazines\001Sports & Leisure");
	m_interest[std::string("Y")] =std::string("News & Magazines\001Teens");
	m_interest[std::string("Z")] =std::string("News & Magazines\001Travel & Regional");
	m_interest[std::string(".")] =std::string("News & Magazines\001Women's Interest");
	m_interest[std::string("]")] =std::string("News & Magazines\001Others");
	m_interest[std::string("0")] =std::string("Games\001Action");
	m_interest[std::string("1")] =std::string("Games\001Adventure");
	m_interest[std::string("2")] =std::string("Games\001Arcade");
	m_interest[std::string("3")] =std::string("Games\001Board");
	m_interest[std::string("4")] =std::string("Games\001Card");
	m_interest[std::string("5")] =std::string("Games\001Casino");
	m_interest[std::string("6")] =std::string("Games\001Casual");

	m_interest[std::string("~")] =std::string("Games\001Dice");
	m_interest[std::string("!")] =std::string("Games\001Educational");
	m_interest[std::string("@")] =std::string("Games\001Family");
	m_interest[std::string("#")] =std::string("Games\001Music");
	m_interest[std::string("$")] =std::string("Games\001Puzzle");
	m_interest[std::string("%")] =std::string("Games\001Racing");
	m_interest[std::string("^")] =std::string("Games\001Role Playing");
	m_interest[std::string("&")] =std::string("Games\001Simulation");
	m_interest[std::string("*")] =std::string("Games\001Sports");
	m_interest[std::string("(")] =std::string("Games\001Strategy");
	m_interest[std::string(")")] =std::string("Games\001Trivia");
	m_interest[std::string("+")] =std::string("Games\001Word");
	m_interest[std::string(";")] =std::string("Games\001Others");
}

bool GetFile(const std::string& path, std::vector<std::string>& vFile)
{
	DIR *dp;
	struct dirent *dir;
	vFile.clear();
	if((dp = opendir(path.c_str())) == NULL)
	{
		std::stringstream s;
		s<<"DataUpate GetFile opendir fail "<<path;
		log(LOG_ERROR, s.str());
		return false;
	}
	while((dir = readdir(dp)) != NULL)
	{
		if(8 == dir->d_type) 
		{
			//vFile.push_back(dir->d_name);
			std::string curPath = path + "/" + dir->d_name;
			vFile.push_back(curPath);
		}
	}
	closedir(dp);
	return true;
}

void CDmpProc::run()
{
	while (is_running&&g_delete)
	{
		g_lock.lock();
		int size = g_vDelFile.size();
		std::string path = "";
		if(size > 0)
		{
			path = g_vDelFile[size -1];
			g_vDelFile.pop_back();
			g_lock.unlock();
			//DeleteDmp(path);
			DeleteDmpRC(path);
			std::cout<<"thread "<<tid<<" delete "<<path<<std::endl;
		}
		else
		{
			g_delete =false;
			is_running = false;
			g_lock.unlock();
		}
	}
	while(is_running && g_set)
	{
		g_lock.lock();
		int size = g_vAddFile.size();
		std::string path = "";
		if(size > 0)
		{
			path = g_vAddFile[size -1];
			g_vAddFile.pop_back();
			g_lock.unlock();
			//SetDmp(path);
			SetDmpRC(path);
			//GetDmpFromFile(path);
			std::cout<<"thread "<<tid<<" set "<<path<<std::endl;
		}
		else
		{
			g_set =false;
			is_running = false;
			g_lock.unlock();
		}
	}
}

bool CDmpProc::SetTest(std::string& file)
{
	ofstream out(file);  
	if (!out.is_open())  
	{ 
		string str = "SetDmp open fail " + file;
		log(LOG_ERROR, str);
		return false;
	}
	std::string key = "", field = "", devId = "20170809001";
	unsigned long  nDeviceid =  BKDRHash(devId.c_str());
	std::stringstream sd;
	sd<<nDeviceid;
	std::string id = sd.str();

	if(!SplitKey(id,  key, field, 8, 7)) //前4bit 作为key.
	{
		return false;
	}
	out<<key<<"\t"<<field<<"\t"<<"a|m|1"<<"\n";

	devId = "20170809002";
	nDeviceid =  BKDRHash(devId.c_str());

	sd.str("");
	sd<<nDeviceid;
	id = sd.str();	

	if(!SplitKey(id,  key, field, 8, 7)) //前4bit 作为key.
	{
		return false;
	}
	out<<key<<"\t"<<field<<"\t"<<"b|f|2"<<"\n";

	devId = "20170809003";
	//unsigned long  id = BKDRHash(devId.c_str());
	nDeviceid =  BKDRHash(devId.c_str());

	sd.str("");
	sd<<nDeviceid;
	id = sd.str();

	if(!SplitKey(id,  key, field, 8, 7)) //前4bit 作为key.
	{
		return false;
	}
	out<<key<<"\t"<<field<<"\t"<<"c|m|3"<<"\n";
	devId = "20170809004";

	//unsigned long  id =  BKDRHash(devId.c_str());
	nDeviceid =  BKDRHash(devId.c_str());

	sd.str("");
	sd<<nDeviceid;
	id = sd.str();

	if(!SplitKey(id,  key, field, 8, 7)) //前4bit 作为key.
	{
		return false;
	}
	out<<key<<"\t"<<field<<"\t"<<"d|f|4"<<"\n";
	out.close();
	return true;
}



bool CDmpProc::SetDmpRCKeyValue(const std::string& deviceId, const std::string& dmpidx)
{
	if(NULL == m_pRedis)
	{
		std::cout<<"SetDmp m_pRedis is null ";
		return false;
	}
	struct timeval time3, time4;
	gettimeofday(&time3, NULL);

	std::map<std::string, std::string> mapFv;

	std::string key = "", field = "";

	unsigned long  nDeviceid =   BKDRHash(deviceId.c_str());

	std::stringstream sd;
	sd<<nDeviceid;
	std::string id = sd.str(),  efield = "";

	if(!SplitKey(id,  key, field, 8, 7))//前4bit 作为key.
	{
		return false;
	}
	Encode(field, efield);
	mapFv[efield] = dmpidx;

	int num  = 0;
	while(num < 20)
	{
		try 
		{
			m_pRedis->hmset(key,mapFv);
			break;
		}
		catch (r3c::CRedisException& ex)
		{
			//log(LOG_ERROR, ex.str());
		}
		++num;
	}
	if(num >= 20)
	{
		std::cout<<" set deviceid: "<<deviceId<<" fail "<<std::endl;
		return false;
	}

	gettimeofday(&time4, NULL);
	double dtime = double((time4.tv_sec - time3.tv_sec) * 1000 + (time4.tv_usec - time3.tv_usec) / 1000.0);

	std::cout<<"set deviceid: "<<deviceId<<"\tidx:"<<dmpidx<<"\thash: "<<nDeviceid<<"\tkey: "<<key<<"\t"<<"field: "<<field<<" finish costtime\t"<<dtime;
	return true;
}

int main(int argc, char **argv)
{
	if(5 == argc)
	{
		CDmpProc obj;
        std::stringstream s;
        s<<argv[2]<<"|"<<argv[3]<<"|"<<argv[4];
		obj.SetDmpRCKeyValue(argv[1], s.str());
	}else if( 2== argc)
	{
		CDmpProc obj;
		SInterest sInterest;
        std::string deviceId = argv[1];
		obj.GetDmp(deviceId,sInterest);
		std::cout<<" len; "<<sInterest.mInterest.size();
		std::map< std::string, std::vector<std::string> >::iterator itr1 = sInterest.mInterest.begin();
		std::cout<<"\tinterest: \n";
		for(; itr1 !=  sInterest.mInterest.end(); itr1++)
		{
			auto itrv = itr1->second.begin();
			for(; itrv != itr1->second.end(); itrv++)
				std::cout<<"\t"<<itr1->first<<"\t"<<*itrv<<std::endl;
			if(itr1->second.begin() == itr1->second.end())
			{
				std::cout<<"\t"<<itr1->first<<std::endl;
			}
		}
		std::cout<<"\tage: "<<sInterest.age<<std::endl;
		std::cout<<"\tgender: "<<sInterest.gender<<std::endl;
	}
	else
	{
		std::cout<<"param error  ,1. SetDmp   ./dmp_redis  key    intrest gender age \n  2. GetDmp:  ./dmp_redis  key  "<<std::endl;
	}
	return 0;

	/*std::string file = "./part0", deviceId = "20170809001", ret = "";
	CDmpProc obj;
	obj.SetTest(file);
	SInterest sInterest;
	obj.GetDmp(deviceId,sInterest);
	std::cout<<" len; "<<sInterest.mInterest.size();
	std::map< std::string, std::vector<std::string> >::iterator itr1 = sInterest.mInterest.begin();
	for(; itr1 !=  sInterest.mInterest.end(); itr1++)
	{
	auto itrv = itr1->second.begin();
	for(; itrv != itr1->second.end(); itrv++ )
	std::cout<<" "<<itr1->first<<" "<<*itrv<<std::endl;
	}
	std::cout<<"ret :"<<ret<<std::endl;
	*/
	return 0;


	g_vAddFile.clear();
	g_vDelFile.clear();
	std::string setpath = "./data", delpath =  "./deldata"; 
	if(!GetFile(setpath,  g_vAddFile) || !GetFile(delpath, g_vDelFile))
	{
		return false;
	}
	std::stringstream sinfo;
	sinfo<<"1. delete file num:  "<<g_vDelFile.size()<<"\tset file num: "<<g_vAddFile.size();
	log(INFO, sinfo.str());
	int nThread = 20;
	CDmpProc *pDmpProc = new CDmpProc[nThread];

	//1.delete.
	g_delete = false;
	g_set = false;
	nThread = 1;
	for (int i = 0; i < nThread; i++)
	{
		pDmpProc[i].start();
	}
	for(int i = 0; i < nThread; i++)
	{
		pDmpProc[i].join();
	}
	sinfo.str("");  
	sinfo<<"2. delete data finish";
	log(INFO, sinfo.str());

	//2. set
	g_delete = false;
	g_set =  true;
	nThread = 1;
	for (int i = 0; i < nThread; i++)
	{
		pDmpProc[i].start();
	}
	for(int i = 0; i < nThread; i++)
	{
		pDmpProc[i].join();
	}
	sinfo.str("");  
	sinfo<<"2. set data finish";
	log(INFO, sinfo.str());
	delete []pDmpProc;
}
