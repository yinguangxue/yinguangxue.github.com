#ifndef _REDIS_H_
#define _REDIS_H_

#include <iostream>
#include <string.h>
#include <string>
#include <stdio.h>

#include <hiredis.h>

class Redis
{
public:
	Redis(string& ip, int port):m_pConnect(NULL),m_pReply(NULL)
	{
		m_pConnect = redisConnect(ip.c_str(), port);
		if(m_pConnect != NULL && m_pConnect->err)
		{
			printf("connect error: %s\n", m_pConnect->errstr);
		}
	}
	~Redis()
	{
		if(m_pReply)
		{
			freeReplyObject(m_pReply);
			m_pReply = NULL;
		}
		if(m_pConnect)
		{
			redisFree(m_pConnect);  
			m_pReply = NULL;
		}
	}


	std::string get(const std::string& key)
	{
		if(NULL == m_pConnect)
		{
			cout<<" m_pConnect is null !\n";
			return "";
		}
		//m_pReply = (redisReply*)redisCommand(m_pConnect, "GET %s", key.c_str());
                string key1 = "M2_10001427 M2_10004037 M2_10001427 M2"; 
                m_pReply = (redisReply*)redisCommand(m_pConnect, "mget  %s", key1.c_str());
		if(NULL == m_pReply || m_pReply->type != REDIS_REPLY_STRING)
		{
			cout<<"m_pReply is null!\n";
			return "";
		}
		//cout<<" redis_reply_string: "<<REDIS_REPLY_STRING<<endl;
		std::string str = m_pReply->str;
		freeReplyObject(m_pReply);
		m_pReply = NULL;
		return str;
	}

	void set(const std::string& key, const std::string& value)
	{
		if(NULL == m_pConnect)
		{
			cout<<" m_pConnect is null !\n";
		}
		redisCommand(m_pConnect, "SET %s %s", key.c_str(), value.c_str());
	}
	
private:
	redisContext *m_pConnect; 
	redisReply   *m_pReply;

};

#endif  //_REDIS_H_
