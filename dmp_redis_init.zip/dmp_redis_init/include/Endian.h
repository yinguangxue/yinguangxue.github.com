#ifndef		ENDIAN_H
#define		ENDIAN_H
#include <stdio.h>

inline void convert_endian(void *buf, size_t len)
{
	char *cbuf = (char *)buf;
	char c;
	for (size_t i=0; i<len/2; i++)
	{
		c = cbuf[i];
		cbuf[i] = cbuf[len-i-1];
		cbuf[len-i-1] = c;
	}
}

template <typename T>
inline void convert_endian(T& t)
{
	convert_endian((char *)&t, sizeof(t));
}

inline bool is_big_endian()
{
	int i=1;
	return *(char *)&i != 1;
}

template <typename T>
inline void ace(T& t)
{
	if (is_big_endian())
	{
		convert_endian(t);
	}
}
inline void ace(void *buf, size_t len)
{
	if (is_big_endian())
	{
		convert_endian(buf, len);
	}
}
#endif // ENDIAN_H_INCLUDED