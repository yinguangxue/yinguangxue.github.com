#ifndef		SERIALIZE_H
#define		SERIALIZE_H
#include <string>
#include <vector>
#include <map>
#include <set>
#include <ext/hash_map>
#include <ext/hash_set>
using namespace std;
using namespace __gnu_cxx;
#include "util.h"
#include "Endian.h"

using namespace std;

template <typename S>
class SerializeImp;
template <typename S>
class UnSerializeImp;
class Serialize;
class UnSerialize;

struct vint
{
	uint32_t i;
	vint():i(0)
	{

	}
	vint(uint32_t v):i(v)
	{

	}

	inline vint& operator=(const uint32_t& n)
	{
		i = n;
		return *this;
	}
	operator uint32_t()
	{
		return i;
	}
};

struct Serializable
{
	void serialize(Serialize &s){}
	void unserialize(UnSerialize& s){}
};

class Serialize
{
protected:
	Serialize *s; //filewrite pointer.
public:
	Serialize():s(NULL)
	{
	}
	template <typename T>
	Serialize(T& t):s(new SerializeImp<T>(t))
	{
	}
	virtual void operator()(const void *buf, size_t len)
	{
		s->operator()(buf, len); 
	}
	template <typename T>
	void operator()(const T& t) //��������Ĳ���
	{
		t.serialize(*this);
	}

	template <typename T>
	void operator()(const vector<T>& t) //vector<roads>
	{
		uint32_t n = t.size();
		operator()(n);
		for (size_t i=0; i<n; i++)
		{
			operator()(t[i]);
		}
	}
	template <typename T, typename U>
	void operator()(const pair<T, U>& t)
	{
		operator()(t.first);
		operator()(t.second);
	}
	template <typename T>
	void operator()(const set<T>& t)
	{
		uint32_t n = t.size();
		operator()(n);
		for (typename set<T>::iterator it = t.begin(); it != t.end(); ++it)
		{
			operator()(*it);
		}
	}
	template <typename T, typename U>
	void operator()(const hash_set<T, U>& t)
	{
		uint32_t n = t.size();
		operator()(n);
		for (typename hash_set<T, U>::iterator it = t.begin(); it != t.end(); ++it)
		{
			operator()(*it);
		}
	}
	template <typename T, typename U>
	void operator()(const map<T, U>& t)
	{
		uint32_t n = t.size();
		operator()(n);
		for (typename map<T, U>::const_iterator it = t.begin(); it != t.end(); ++it)
		{
			operator()(*it);
		}
	}
	template <typename T, typename U, typename V>
	void operator()(const hash_map<T, U, V>& t)
	{
		uint32_t n = t.size();
		operator()(n);
		for (typename hash_map<T, U, V>::const_iterator it = t.begin(); it != t.end(); ++it)
		{
			operator()(*it);
		}
	}
	virtual ~Serialize()
	{
		safe_delete(s);
	}
	virtual bool isValid()
	{
		return s->isValid();
	}
};

template <>
inline void Serialize::operator()<bool>(const bool& t)
{
	operator()(&t, sizeof(t));
}

template <>
inline void Serialize::operator()<char>(const char& t)
{
	operator()(&t, sizeof(t));
}

template <>
inline void Serialize::operator()<unsigned char>(const unsigned char& t)
{
	operator()(&t, sizeof(t));
}
template <>
inline void Serialize::operator()<short>(const short& t)
{
	if (is_big_endian())
	{
		short tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<unsigned short>(const unsigned short& t)
{
	if (is_big_endian())
	{
		unsigned short tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<int>(const int& t)
{
	if (is_big_endian())
	{
		int tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<unsigned int>(const unsigned int& t)
{
	if (is_big_endian())
	{
		unsigned int tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<long>(const long& t)
{
	if (is_big_endian())
	{
		long tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<unsigned long>(const unsigned long& t)
{
	if (is_big_endian())
	{
		unsigned long tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<long long>(const long long& t)
{
	if (is_big_endian())
	{
		long long tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<unsigned long long>(const unsigned long long& t)
{
	if (is_big_endian())
	{
		unsigned long long tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<float>(const float& t)
{
	if (is_big_endian())
	{
		float tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<double>(const double& t)
{
	if (is_big_endian())
	{
		double tt = t;
		convert_endian(&tt, sizeof(tt));
		operator()(&tt, sizeof(tt));
	}
	else
	{
		operator()(&t, sizeof(t));
	}
}
template <>
inline void Serialize::operator()<vint>(const vint& t)
{
	uint32_t i = t.i;
	if (i<64)
	{
		operator()((uint8_t)(i<<2));
	}
	else if (i<16384)
	{
		operator()((uint16_t)((i<<2)+1));
	}
	else if (i<1073741824)
	{
		operator()((unsigned)((i<<2)+2));
	}
	else
	{
		operator()((unsigned)((i<<2)+3));
		operator()((uint8_t)(i>>30));
	}
}
template <>
inline void Serialize::operator()<string>(const string& s)
{
	vint n = s.size();
	operator()(n); //д�ַ�������
	operator()(s.c_str(), n); //д���ַ���
}

class UnSerialize
{
protected:
	UnSerialize *s;  //filereader
public:
	UnSerialize():s(NULL)
	{
	}
	template <typename T>
	UnSerialize(T& t):s(new UnSerializeImp<T>(t))
	{
	}
	virtual void operator()(void *buf, size_t len)
	{
		s->operator()(buf, len);
	}
	template <typename T>
	T& operator()(T& t)
	{
		t.unserialize(*this);
		return t;
	}
	template <typename T>
	vector<T>& operator()(vector<T>& t)
	{
		uint32_t n;
		operator()(n);
		t.resize(n);
		for (size_t i=0; i<n; i++)
		{
			operator()(t[i]);
		}
		return t;
	}
	template <typename T, typename U>
	pair<T, U>& operator()(pair<T, U>& t)
	{
		operator()(t.first);
		operator()(t.second);
		return t;
	}
	template <typename T>
	set<T>& operator()(set<T>& t)
	{
		t.clear();
		uint32_t n;
		operator()(n);
		for (size_t i=0; i<n; i++)
		{
			T p;
			operator()(p);
			t.insert(p);
		}
		return t;
	}
	template <typename T, typename U>
	hash_set<T, U>& operator()(hash_set<T, U>& t)
	{
		t.clear();
		uint32_t n;
		operator()(n);
		for (size_t i=0; i<n; i++)
		{
			T p;
			operator()(p);
			t.insert(p);
		}
		return t;
	}
	template <typename T, typename U>
	map<T, U>& operator()(map<T, U>& t)
	{
		t.clear();
		uint32_t n;
		operator()(n);
		for (size_t i=0; i<n; i++)
		{
			pair<T, U> p;
			operator()(p);
			t.insert(p);
		}
		return t;
	}
	template <typename T, typename U, typename V>
	hash_map<T, U, V>& operator()(hash_map<T, U, V>& t)
	{
		t.clear();
		uint32_t n;
		operator()(n);
		for (size_t i=0; i<n; i++)
		{
			pair<T, U> p;
			operator()(p);
			t.insert(p);
		}
		return t;
	}

	char *operator()()
	{
		uint32_t n;
		operator()(&n, sizeof(n));
		ace(n);
		char *c = new char[n+1];
		c[n] = 0;
		operator()(c, n);
		return c;
	}
	virtual ~UnSerialize()
	{
		safe_delete(s);
	}
	virtual bool isValid()
	{
		return s->isValid();
	}
};

template <>
inline bool& UnSerialize::operator()<bool>(bool& t)
{
	operator()(&t, sizeof(t));
	return t;
}

template <>
inline char& UnSerialize::operator()<char>(char& t)
{
	operator()(&t, sizeof(t));
	return t;
}
template <>
inline unsigned char& UnSerialize::operator()<unsigned char>(unsigned char& t)
{
	operator()(&t, sizeof(t));
	return t;
}

template <>
inline short& UnSerialize::operator()<short>(short& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline unsigned short& UnSerialize::operator()<unsigned short>(unsigned short& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline int& UnSerialize::operator()<int>(int& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline unsigned int& UnSerialize::operator()<unsigned int>(unsigned int& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline long& UnSerialize::operator()<long>(long& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline unsigned long& UnSerialize::operator()<unsigned long>(unsigned long& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline long long& UnSerialize::operator()<long long>(long long& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline unsigned long long& UnSerialize::operator()<unsigned long long>(unsigned long long& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline double& UnSerialize::operator()<double>(double& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline float& UnSerialize::operator()<float>(float& t)
{
	operator()(&t, sizeof(t));
	ace(&t, sizeof(t));
	return t;
}
template <>
inline vint& UnSerialize::operator()<vint>(vint& t)
{
	uint32_t &i = t.i;
	uint8_t c;
	operator()(c);
	uint32_t n = c&3;
	if (n == 0)
	{
		i= (c>>2);
	}
	else if (n == 1)
	{
		uint8_t c1;
		operator()(c1);
		i = ((uint32_t(c1)<<6)+(c>>2));
	}
	else if (n == 2)
	{
		uint8_t *b = (uint8_t *)&i;
		operator()(b+1, 3);
		b[0] = c;
		ace(b, 4);
		i = (i>>2);
	}
	else
	{
		uint8_t *b = (uint8_t *)&i;
		operator()(b, 4);
		ace(b, 4);
		i=(i<<6)+(c>>2);
	}
	return t;
}
template <>
inline string& UnSerialize::operator()<string>(string& s)
{
	vint n;
	operator()(n);
	s.resize(n);
	char *cp = (char *)s.c_str();
	operator()(cp, n);
	return s;
}


#endif // SERIALIZE_H_INCLUDED
