#ifndef  STRINGSPLITTER_H
#define STRINGSPLITTER_H
#include <vector>
#include <string>
#include <string.h>
#include <sstream>
#include <stdint.h>
#include <assert.h>
#include <stdarg.h>
#include "util.h"
#include <iconv.h>
using namespace std;

struct StringSplitter
{
	bool gbk;
	StringSplitter(bool isgbk = false):gbk(isgbk)
	{
	}
	inline void operator()(vector<string>& out, const string& in, const char sp, bool neglect = false)
	{
		return operator()(out, in.c_str(), in.size(), sp, INVALID_ID, neglect);
	}
	inline void operator()(vector<string>& out, const string& in, const char* sp, bool neglect = false)
	{
		return operator()(out, in.c_str(), in.size(), sp, INVALID_ID, neglect);
	}
	inline void operator()(vector<string>& out, const string& in, const char sp, uint32_t max_field_num, bool neglect = false)
	{
		return operator()(out, in.c_str(), in.size(), sp, max_field_num, neglect);
	}
	inline void operator()(vector<string>& out, const string& in, const char* sp, uint32_t max_field_num, bool neglect = false)
	{
		return operator()(out, in.c_str(), in.size(), sp, max_field_num, neglect);
	}
	void operator()(vector<string>& out, const char *in, const char sp, bool neglect = false)
	{
		return operator()(out, in, strlen(in), sp, INVALID_ID, neglect);
	}
	void operator()(vector<string>& out, const char *in, const char* sp, bool neglect = false)
	{
		return operator()(out, in, strlen(in), sp, INVALID_ID, neglect);
	}
	void operator()(vector<string>& out, const char *in, size_t len, const char sp, uint32_t max_field_num, bool neglect = false)
	{
		out.clear();
		if (in == NULL||in[0]==0) return;
		const char *p = in, *lp;
		while (true)
		{
			lp = p;
			while (p<in+len)
			{
				if (*p == sp)
				{
					break;
				}
				else
				{
					if (gbk && *p<0)
					{
						p++;
						if (*p) p++;
					}
					else
					{
						p++;
					}
				}
			}
			if (p>=in+len)
			{
				if (!neglect || p>lp)
					out.push_back(string(lp, p-lp));
				break;
			}
			if (out.size()==max_field_num-1)
			{
				p = in+len;
				out.push_back(string(lp, p-lp));
				break;
			}
			if (!neglect || p>lp)
				out.push_back(string(lp, p-lp));
			p++;
		}
	}
	void operator()(vector<string>& out, const char *in, size_t len, const char* sp, uint32_t max_field_num, bool neglect = false)
	{
		out.clear();
		if (in == NULL) return;
		if (strlen(sp) == 1)
		{
			operator()(out, in, len, sp[0], max_field_num, neglect);
			return;
		}
		const char *p = in, *lp;
		while (true)
		{
			lp = p;
			while (p < in+len)
			{
				const char *cp = sp;
				while (*cp != '\0')
				{
					if (*cp == *p)
					{
						break;
					}
					cp++;
				}
				if (*cp != '\0')
				{
					break;
				}

				if (gbk && *p<0)
				{
					p++;
					if (*p) p++;
				}
				else
				{
					p++;
				}
			}
			if (p >= in+len)
			{
				if (!neglect || p>lp)
					out.push_back(string(lp, p-lp));
				break;
			}

			if (out.size()==max_field_num-1)
			{
				p = in+len;
				out.push_back(string(lp, p-lp));
				break;
			}
			if (!neglect || p>lp)
				out.push_back(string(lp, p-lp));
			p++;
		}
	}
	size_t operator()(const char **out, const char *in, const char sp)
	{
		size_t n = 0;
		if (in == NULL) return n;
		const char *p = in, *lp;
		while (n<255)
		{
			lp = p;
			while (*p)
			{
				if (*p == sp)
				{
					break;
				}
				else
				{
					p++;
				}
			}
			if (*p == 0)
			{
				out[n++]=lp;
				out[n] = p;
				break;
			}
			out[n++] = lp;
			if (gbk && *p<0)
			{
				p++;
				if (*p) p++;
			}
			else
			{
				p++;
			}
		}
		return n;
	}

};
inline vector<string> strsplit(const string& s, char sp)
{
	vector<string> vs;
	StringSplitter()(vs, s, sp);
	return vs;
}
inline vector<string> strsplit(const string& s, const char* sp)
{
	vector<string> vs;
	StringSplitter()(vs, s, sp);
	return vs;
}
inline int csv_nextfield(string& r, const char* s, size_t& lp, char sp = ',')
{
	r.clear();
	uint32_t status = 0;
	stringstream result;
	const char *cp = s+lp;
	while (*cp)
	{
		switch (status)
		{
		case 0://start
			{
				if (*cp == '\"')
				{
					status = 2;
					lp = cp+1-s;
				}
				else if (*cp == '\r' || *cp == '\n')
				{
					lp = cp-s;
					return 1;
				}
				else if (*cp == sp)
				{
					lp = cp+1-s;
					return 0;
				}
				else
				{
					status = 1;
					result<<*cp;
				}
				break;
			}
		case 1://processing no quote
			{
				if (*cp == sp)
				{
					lp = cp+1-s;
					r = result.str();
					return 0;
				}
				else if (*cp == '\r' || *cp == '\n')
				{
					lp = cp-s;
					r = result.str();
					return 0;
				}
				else
				{
					result<<*cp;
				}
				break;
			}
		case 2://processing with quote
			{
				if (*cp == '\"')
				{
					status = 3;
				}
				else
				{
					result<<*cp;
				}
				break;
			}
		case 3://get quote
			{
				if (*cp == '\"')
				{
					result<<*cp;
					status = 2;
				}
				else if (*cp == sp)
				{
					lp = cp+1-s;
					r = result.str();
					return 0;
				}
				else if (*cp == '\r' || *cp == '\n')
				{
					lp = cp-s;
					r = result.str();
					return 0;
				}
				else
				{
					return -1;
				}
				break;
			}
		default:
			{
				assert(0);
				break;
			}
		}
		cp++;
	}
	if (status == 1)
	{
		r = result.str();
		return 0;
	}
	return 1;
}
inline int csv_nextrecord(vector<string>& vs, const char *s, size_t& lp, char sp = ',')
{
	vs.clear();
	while (s[lp] == '\r' || s[lp] == '\n') lp++;
	if (s[lp] == '\0') return 1;
	string field;
	int ret = 0;
	while (true)
	{
		ret = csv_nextfield(field, s, lp, sp);
		if (ret == -1) return -1;
		if (ret == 1) return 0;
		vs.push_back(field);
	}
	return 0;
}
inline vector<string> csvsplit(const string& s, char sp = ',')
{
	vector<string> vs;
	size_t lp = 0;
	csv_nextrecord(vs, s.c_str(), lp, sp);
	return vs;
}
template <typename Iterator>
inline string strjoin(const Iterator& it1, const Iterator& it2, char sp)
{
	stringstream ss;
	bool ff = true;
	for (Iterator it = it1; it != it2; ++it)
	{
		if (!ff)
		{
			ss<<sp;
		}
		ff=false;
		ss<<*it;
	}
	return ss.str();
}
inline string strjoin(const vector<string>& in, char sp)
{
	string ss;
	for (size_t i=0; i<in.size(); i++)
	{
		ss+=in[i];
		if (i < in.size()-1)
		{
			ss+=sp;
		}
	}
	return ss;
}
inline string strjoin(const vector<string>& in, size_t pos, const string& sp)
{
	string ss;
	for (size_t i=pos; i<in.size(); i++)
	{
		ss+=in[i];
		if (i < in.size()-1)
		{
			ss+=sp;
		}
	}
	return ss;
}
inline string strjoin(const vector<string>& in, size_t pos, char sp)
{
	string ss;
	for (size_t i=pos; i<in.size(); i++)
	{
		ss+=in[i];
		if (i < in.size()-1)
		{
			ss+=sp;
		}
	}
	return ss;
}
inline string strjoin(const vector<string>& in, const string& sp)
{
	string ss;
	for (size_t i=0; i<in.size(); i++)
	{
		ss+=in[i];
		if (i < in.size()-1)
		{
			ss+=sp;
		}
	}
	return ss;
}
inline string strreplace(const string& l, const string& ws, const string& wr, uint32_t count=INVALID_ID)
{
	stringstream s;
	size_t p, lp;
	p = lp = 0;
	uint32_t n = 0;
	while (n<count)
	{
		p = l.find(ws, lp);
		if (p == string::npos)
		{
			break;
		}
		s<<l.substr(lp, p-lp);
		s<<wr;
		lp=p+ws.size();
		n++;
	}
	s<<l.c_str()+lp;
	return s.str();
}
inline string lower(string s)
{
	for (size_t i=0; i<s.size(); i++)
	{
		if (s[i]<0)
		{
			i++;
		}
		else
		{
			s[i] = tolower(s[i]);
		}
	}
	return s;
}

inline string upper(string s)
{
	for (size_t i=0; i<s.size(); i++)
	{
		if (s[i]<0)
		{
			i++;
		}
		else
		{
			s[i] = toupper(s[i]);
		}
	}
	return s;
}
inline string trim(string s, char c)
{
	int wp = 0;
	for (size_t i=0; i<s.size(); i++)
	{
		if (s[i]!=c)
		{
			s[wp++] = s[i];
		}
	}
	s.erase(s.begin()+wp, s.end());
	return s;
}
inline string trim(string s, const char* cp)
{
	int wp = 0;
	for (size_t i=0; i<s.size(); i++)
	{
		if (strchr(cp, s[i]) == NULL)
		{
			s[wp++] = s[i];
		}
	}
	s.erase(s.begin()+wp, s.end());
	return s;
}
inline string rstrip(string s, char c = ' ')
{
	int wp = 0;
	for (wp = s.size(); wp>0 && s[wp-1]==c; wp--);
	return s.substr(0, wp);
}
inline string rstrip(string s, const char* cp)
{
	size_t len = strlen(cp);
	int p2 = 0;
	for (p2 = s.size(); p2>0; p2--)
	{
		bool flag = false;
		for (size_t i=0; i<len; i++)
		{
			if (s[p2-1] == cp[i])
			{
				flag = true;
				break;
			}
		}
		if (!flag) break;

	}
	return s.substr(0, p2);
}
inline string lstrip(string s, char c = ' ')
{
	size_t wp = 0;
	for (wp = 0; wp<s.size() && s[wp]==c; wp++);
	return s.substr(wp, s.size()-wp);
}
inline string lstrip(string s, const char* cp)
{
	size_t len = strlen(cp);
	size_t p1 = 0;
	for (p1 = 0; p1<s.size(); p1++)
	{
		bool flag = false;
		for (size_t i=0; i<len; i++)
		{
			if (s[p1] == cp[i])
			{
				flag = true;
				break;
			}
		}
		if (!flag) break;
	}
	return s.substr(p1, s.size()-p1);
}
inline string strip(string s, char c = ' ')
{
	size_t p1 = 0;
	for (p1 = 0; p1<s.size() && s[p1]==c; p1++);
	int p2 = 0;
	for (p2 = s.size(); p2>0 && s[p2-1]==c; p2--);
	return s.substr(p1, p2-p1);
}
inline string strip(string s, const char* cp)
{
	size_t len = strlen(cp);
	size_t p1 = 0;
	for (p1 = 0; p1<s.size(); p1++)
	{
		bool flag = false;
		for (size_t i=0; i<len; i++)
		{
			if (s[p1] == cp[i])
			{
				flag = true;
				break;
			}
		}
		if (!flag) break;
	}
	int p2 = 0;
	for (p2 = s.size(); p2>0; p2--)
	{
		bool flag = false;
		for (size_t i=0; i<len; i++)
		{
			if (s[p2-1] == cp[i])
			{
				flag = true;
				break;
			}
		}
		if (!flag) break;

	}
	return s.substr(p1, p2-p1);
}
inline bool startwith(const string& s1, const string& s2)
{
	if (s2.size()>s1.size()) return false;
	return strncmp(s1.c_str(), s2.c_str(), s2.size()) == 0;
}
inline bool endwith(const string& s1, const string& s2)
{
	if (s2.size()>s1.size()) return false;
	return strncmp(s1.c_str()+s1.size()-s2.size(), s2.c_str(), s2.size()) == 0;
}
inline bool isHZ(const string& s)
{
	for (size_t i=0; i<s.size(); i++)
	{
		if (s[i]<0) return true;
	}
	return false;
}
inline bool isdigit(const string& s)
{
	for (size_t i=0; i<s.size(); i++)
	{
		if (!isdigit(s[i])) return false;
	}
	return true;
}
inline uint16_t str2short(const char* c)
{
	uint16_t s = (uint8_t)c[0];
	s = s*256+(uint8_t)c[1];
	return s;
}
template <typename T>
inline T str2num(const string& s)
{
	return atoi(s.c_str());
}
template <>
inline bool str2num<bool>(const string& s)
{
	return s.compare("1")==0 || lower(s).compare("true")==0;
}
template <>
inline int str2num<int>(const string& s)
{
	return atoi(s.c_str());
}
template <>
inline unsigned int str2num<unsigned int>(const string& s)
{
	return strtoul(s.c_str(), NULL, 10);
}
template <>
inline long str2num<long>(const string& s)
{
	return atol(s.c_str());
}
template <>
inline unsigned long str2num<unsigned long>(const string& s)
{
	return strtoul(s.c_str(), NULL, 10);
}
template <>
inline long long str2num<long long>(const string& s)
{
	return strtoll(s.c_str(), NULL, 10);
}
template <>
inline unsigned long long str2num<unsigned long long>(const string& s)
{
	return strtoull(s.c_str(), NULL, 10);
}
template <>
inline float str2num<float>(const string& s)
{
	return atof(s.c_str());
}
template <>
inline double str2num<double>(const string& s)
{
	return atof(s.c_str());
}

template <typename T>
inline string num2str(T t)
{
	char buf[20];
	snprintf(buf, 20, "%d", t);
	return string(buf);
}
template <>
inline string num2str<unsigned int>(unsigned int t)
{
	char buf[20];
	snprintf(buf, 20, "%u", t);
	return string(buf);
}
template <>
inline string num2str<unsigned long>(unsigned long t)
{
	char buf[20];
	snprintf(buf, 20, "%lu", t);
	return string(buf);
}
template <>
inline string num2str<float>(float t)
{
	char buf[20];
	snprintf(buf, 20, "%f", t);
	return string(buf);
}
template <>
inline string num2str<double>(double t)
{
	char buf[30];
	snprintf(buf, 30, "%.16g", t);
	return string(buf);
}
template <>
inline string num2str<long>(long t)
{
	char buf[20];
	snprintf(buf, 20, "%ld", t);
	return string(buf);
}
template <>
inline string num2str<long long>(long long t)
{
	char buf[20];
	snprintf(buf, 20, "%lld", t);
	return string(buf);
}
template <>
inline string num2str<unsigned long long>(unsigned long long t)
{
	char buf[20];
	snprintf(buf, 20, "%llu", t);
	return string(buf);
}
template <typename T>
inline T hex2num(const string& s)
{
	T n = 0;
	for (size_t i=0; i<s.size(); i++)
	{
		n = n*16+(s[i]<='9'?s[i]-'0':toupper(s[i])-'A'+10);
	}
	return n;
}

template <typename T>
inline string num2hex(T t)
{
	string s;
	if (t == 0)
	{
		s = "0";
	}
	else
	{
		while (t)
		{
			char c = t%16;
			if (c<10)
			{
				c+='0';
			}
			else
			{
				c+='A';
			}
			s.insert(s.begin(), c);
			t/=16;
		}
	}
	return s;
}

inline string pack_string(const char *format, ...)
{
	string s;
	uint32_t size=1024;
	while (size<=10*1024*1024)
	{
		s.resize(size);
		va_list pvar;
		va_start(pvar, format);
		uint32_t ret = vsnprintf((char*)s.c_str(), size, format, pvar);
		if (ret < size)
		{
			s.resize(ret);
			break;
		}
		else
		{
			size=ret+1;
		}
	}
	return s;
}
inline string convert_xml(const string& old_str)
{
	string new_str;
	for (size_t i=0; i<old_str.size(); i++)
	{
		switch(old_str[i])
		{
		case '<':
			new_str.append("&lt;");
			break;
		case '>':
			new_str.append("&gt;");
			break;
		case '&':
			new_str.append("&amp;");
			break;
		case '\"':
			new_str.append("&quot;");
			break;
		case '\'':
			new_str.append("&apos;");
			break;
		default:
			new_str.push_back(old_str[i]);
			break;
		}
	}
	return new_str;
}

template <typename T>
inline void xml_add_field(stringstream& result, const string& field_name, const T& field_value, bool is_cdata = false)
{
	if (is_cdata)
	{
		result<<"<"<<field_name<<"><![CDATA["<<field_value<<"]]></"<<field_name<<">";
	}
	else
	{
		result<<"<"<<field_name<<">"<<field_value<<"</"<<field_name<<">";
	}
}
template <>
inline void xml_add_field<string>(stringstream& result, const string& field_name, const string& field_value, bool is_cdata)
{
	if (is_cdata)
	{
		result<<"<"<<field_name<<"><![CDATA["<<field_value<<"]]></"<<field_name<<">";
	}
	else
	{
		result<<"<"<<field_name<<">"<<convert_xml(field_value)<<"</"<<field_name<<">";
	}
}
inline bool restore_xml(string& s)
{
	size_t rp, wp;
	rp = wp = 0;
	while (rp<s.size())
	{
		if (s[rp] == '&')
		{
			if (strncasecmp(s.c_str()+rp, "&lt;", 4) == 0)
			{
				s[wp++]='<';
				rp+=3;
			}
			else if (strncasecmp(s.c_str()+rp, "&gt;", 4) == 0)
			{
				s[wp++]='>';
				rp+=3;
			}
			else if (strncasecmp(s.c_str()+rp, "&amp;", 5) == 0)
			{
				s[wp++]='&';
				rp+=4;
			}
			else if (strncasecmp(s.c_str()+rp, "&quot;", 6) == 0)
			{
				s[wp++]='\"';
				rp+=5;
			}
			else if (strncasecmp(s.c_str()+rp, "&apos;", 6) == 0)
			{
				s[wp++]='\'';
				rp+=5;
			}
			else if (strncasecmp(s.c_str()+rp, "&nbsp;", 6) == 0)
			{
				s[wp++]=' ';
				rp+=5;
			}
			else if (strncasecmp(s.c_str()+rp, "&copy;", 6) == 0)
			{
				s[wp++]='C';
				rp+=5;
			}
			else if (strncasecmp(s.c_str()+rp, "&reg;", 6) == 0)
			{
				s[wp++]='R';
				rp+=4;
			}
			else if (s[rp+1]=='#')
			{
				rp+=2;
				int n = atoi(s.c_str()+rp);
				while (isdigit(s[rp])) rp++;
				assert(s[rp] == ';');
				rp++;
				while (n)
				{
					s[wp++]=n%256;
					n/=256;
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			s[wp++]=s[rp++];
		}
	}
	s.erase(s.begin()+wp, s.end());
	return true;
}

inline string convert_json(const string& old_str)
{
	string new_str;
	for (size_t i=0; i<old_str.size(); i++)
	{
		switch(old_str[i])
		{
		case '\"':
			new_str.append("\\\"");
			break;
		case '\\':
			new_str.append("\\\\");
			break;
		case '/':
			new_str.append("\\/");
			break;
		case '\b':
			new_str.append("\\b");
			break;
		case '\f':
			new_str.append("\\f");
			break;
		case '\n':
			new_str.append("\\n");
			break;
		case '\r':
			new_str.append("\\r");
			break;
		case '\t':
			new_str.append("\\t");
			break;
		default:
			new_str.push_back(old_str[i]);
			break;
		}
	}
	return new_str;
}
inline bool restore_json(string& s)
{
	size_t rp, wp;
	rp = wp = 0;
	while (rp<s.size())
	{
		if (s[rp] == '\\')
		{
			rp++;
			switch(s[rp])
			{
			case '\"':
			case '\\':
			case 'b':
			case 'f':
			case 'r':
			case 'n':
			case 't':
			case '/':
			case 'u':
				break;
			}
			if (strncasecmp(s.c_str()+rp, "&lt;", 4) == 0)
			{
				s[wp++]='<';
				rp+=3;
			}
			else if (strncasecmp(s.c_str()+rp, "&gt;", 4) == 0)
			{
				s[wp++]='>';
				rp+=3;
			}
			else if (strncasecmp(s.c_str()+rp, "&amp;", 5) == 0)
			{
				s[wp++]='&';
				rp+=4;
			}
			else if (strncasecmp(s.c_str()+rp, "&quot;", 6) == 0)
			{
				s[wp++]='\"';
				rp+=5;
			}
			else if (strncasecmp(s.c_str()+rp, "&apos;", 6) == 0)
			{
				s[wp++]='\'';
				rp+=5;
			}
			else if (strncasecmp(s.c_str()+rp, "&nbsp;", 6) == 0)
			{
				s[wp++]=' ';
				rp+=5;
			}
			else if (strncasecmp(s.c_str()+rp, "&copy;", 6) == 0)
			{
				s[wp++]='C';
				rp+=5;
			}
			else if (strncasecmp(s.c_str()+rp, "&reg;", 6) == 0)
			{
				s[wp++]='R';
				rp+=4;
			}
			else if (s[rp+1]=='#')
			{
				rp+=2;
				int n = atoi(s.c_str()+rp);
				while (isdigit(s[rp])) rp++;
				assert(s[rp] == ';');
				rp++;
				while (n)
				{
					s[wp++]=n%256;
					n/=256;
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			s[wp++]=s[rp++];
		}
	}
	s.erase(s.begin()+wp, s.end());
	return true;
}
inline char check_delimiter(const string& l, const char* dels=",\t")
{
	size_t md = 0, mn = 0;
	for (size_t i=0; i<strlen(dels); i++)
	{
		vector<string> vs = strsplit(l, dels[i]);
		if (vs.size()>mn)
		{
			mn = vs.size();
			md = i;
		}
	}
	return dels[md];
}
inline uint64_t parseDateTime(const string& datetime)
{
	uint64_t dt = 0;
	for (size_t i=0; i<datetime.size(); i++)
	{
		if (isdigit(datetime[i]))
		{
			dt = dt*10+datetime[i]-'0';
		}
	}
	return dt;
}




#endif // STRINGSPLITTER_H_INCLUDED
