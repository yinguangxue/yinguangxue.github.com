#ifndef  DMPPROC_H
#define DMPPROC_H

#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <map>
#include <sys/time.h>
#include <time.h>
#include  "r3c.h"
#include "RedisClient.hpp"
#include "log.h"
#include "ConfigReader.h"
#include "jsoncpp/json.h"
#include "Thread.h"
using namespace std;

#define INDEX_REDIS  1
//#define Debug          1

typedef struct Redis
{
	int port;
	int timeout;
	int  connum;
	std::string ip;
	Redis():port(6379),timeout(5),connum(300),ip("10.204.245.2"){}
}SRedis;

typedef struct Interest
{
	int				age;
	std::string  gender;
	std::map< std::string, std::vector<std::string> > mInterest;
	Interest():age(-1), gender("-"){}
}SInterest;


Lock  g_lock;
bool  g_delete = false, g_set = false;
std::vector<std::string> g_vAddFile,  g_vDelFile;

class CDmpProc: public Thread
{
public:

	CDmpProc();
	~CDmpProc();
	virtual void run();
	void LoadRedisConfig(SRedis& sRedis);
	void InitRedis(SRedis& sRedis);
	bool GetDmp(const std::string& deviceId,std::string& ret);
	bool SetDmp(const std::string& file);
	bool SetDmpRC(const std::string& file);
	bool DeleteDmp(const std::string& file);
	bool DeleteDmpRC(const std::string& file);
	bool GetDmp(const std::string& deviceId, SInterest& sInterest);
	
    bool SetDmpRCKeyValue(const std::string& deviceId, const std::string& dmpidx);
	bool SetTest(std::string& file);
	bool TestR3CGetDmp(const std::string& key, const std::string&  field,  std::string& ret);
	bool GetDmpFromFile(const std::string& file);

private:
    
	void InitInterest();
	unsigned long BKDRHash(const char *str);
	bool Encode(const std::string& deviceId, std::string& key);
	bool SplitKey(const std::string& deviceId, std::string& key, std::string& field, int off,  int num);
	void SplitSub(std::string& s, std::string& delim,std::vector<std::string>* ret) ;
	bool ParseInterest(std::string& sIdx, std::vector< std::string >& ret);


private:
	std::map<std::string, std::string> m_interest;
	r3c::CRedisClient						       *m_pRedis;
	CRedisClient										 m_redisClient;  
};

#endif

