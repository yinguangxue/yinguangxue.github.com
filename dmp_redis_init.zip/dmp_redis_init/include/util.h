#ifndef	 UTIL_H
#define   UTIL_H
#include <vector>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <iostream>
#include <sstream>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <stdint.h>
typedef uint32_t docid_t;
typedef uint32_t cityid_t;
using namespace std;
#include <ext/hash_map>
#include <ext/hash_set>

using namespace __gnu_cxx;
#include <stdio.h>
#include <assert.h>

const uint32_t INVALID_ID = uint32_t(-1);


#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))

template <int v>
struct IntType
{
	enum{value=v};
};

struct NullType
{
	char a[0];
};

struct ULLHash
{
	unsigned operator()(uint64_t v) const
	{
		unsigned t = (unsigned)v;
		t ^= (unsigned)(v>>32);
		return t;
	}
};
template <typename T1, typename T2, typename T3>
struct triple
{
	typedef triple<T1, T2, T3> Triple;
	T1 first;
	T2 second;
	T3 third;
	triple()
	{
	}
	triple(const T1& t1, const T2& t2, const T3& t3)
	{
		first = t1;
		second = t2;
		third = t3;
	}
	bool operator<(const Triple& t) const
	{
		if (first == t.first)
		{
			if (second == t.second)
			{
				if (third < t.third)
				{
					return true;
				}
				return false;
			}
			if (second<t.second) return true;
			return false;
		}
		if (first < t.first) return true;
		return false;
	}
	bool operator>(const Triple& t) const
	{
		return t.operator<(*this);
	}
	bool operator==(const Triple& t) const
	{
		return first == t.first && second == t.second && third == t.third;
	}
};
template <typename T1, typename T2, typename T3>
inline triple<T1, T2, T3> make_triple(const T1& t1, const T2& t2, const T3& t3)
{
	return triple<T1, T2, T3>(t1, t2, t3);
}

struct PairHash
{
	template <typename T>
	uint32_t operator()(const pair<T, T>& p) const
	{
		return p.first*p.second;
	}
};
template <typename T, size_t N>
struct PointerArray
{
	T* data[N];
};
template <typename T, size_t ArraySize=256>
struct NArray
{
	size_t len;
	T data[ArraySize];
	typedef T* iterator;
	typedef const T* const_iterator;
	typedef NArray<T, ArraySize> ArrayType;
	NArray():len(0)
	{
		//cout<<0<<" "<<len<<endl;
	}
	NArray(const ArrayType& na)
	{
		copy(na.begin(), na.end(), data);
		len = na.len;
		//cout<<1<<" "<<len<<endl;
	}
	NArray(size_t n, const T& t)
	{
		fill(data, data+n, t);
		len = n;
		//cout<<2<<" "<<len<<endl;
	}
	template <typename Iterator>
	NArray(Iterator it1, Iterator it2):len(0)
	{
		for (Iterator it = it1; it != it2; ++it)
		{
			push_back(*it);
		}
		//cout<<3<<" "<<len<<endl;
	}
	iterator begin()
	{
		return data;
	}
	const_iterator begin() const
	{
		return data;
	}
	iterator end()
	{
		return data+len;
	}
	const_iterator end() const
	{
		return data+len;
	}
	bool empty() const
	{
		return len==0;
	}
	bool full() const
	{
		return len==ArraySize;
	}
	void clear()
	{
		len = 0;
	}
	size_t size() const
	{
		return len;
	}
	T& front()
	{
		return data[0];
	}
	T& back()
	{
		return data[len-1];
	}
	void push_back(const T& t)
	{
		data[len]=t;
		len++;
	}
	void pop_back()
	{
		len--;
	}
	void push_front(const T& t)
	{
		insert(begin(), t);
	}
	void pop_front()
	{
		erase(begin());
	}
	void insert(iterator it, const T& t)
	{
		if (it == end())
		{
			push_back(t);
			return;
		}
		data[len] = data[len-1];
		len++;
		for (iterator it2 = data+len-1; it2 > it; it2--)
		{
			*it2 = *(it2-1);
		}
		*it = t;
		//cout<<"insert:"<<size()<<endl;
	}
	template <typename Iterator>
	void insert(iterator oit, Iterator iit1, Iterator iit2)
	{
		for (Iterator it = iit1; it != iit2; ++it)
		{
			insert(oit, *it);
			oit++;
		}
	}
	void erase(iterator it)
	{
		for (iterator it2 = it; it2 < end()-1; ++it2)
		{
			*it2 = *(it2+1);
		}
		len--;
		//cout<<"erase:"<<size()<<endl;
	}
	void erase(iterator it1, iterator it2)
	{
		if (it2 == end())
		{
			len = it1-begin();
		}
		else
		{
			iterator it;
			for (it = it2; it >= it1; --it)
			{
				erase(it);
			}
		}
	}
	T& operator[](size_t i)
	{
		return data[i];
	}
	ArrayType& operator=(const ArrayType& na)
	{
		if (this != &na)
		{
			copy(na.begin(), na.end(), data);
			len = na.len;
		}

		//cout<<"=:"<<size()<<endl;
		return *this;
	}
};
struct StrHash
{
	uint64_t operator()(const std::string& str) const
	{
		uint32_t b    = 378551;
		uint32_t a    = 63689;
		uint64_t hash = 0;

		for(size_t i = 0; i < str.size(); i++)
		{
			hash = hash * a + str[i];
			a    = a * b;
		}

		return hash;
	}
	uint64_t operator()(const std::string& str, uint32_t field) const
	{
		uint32_t b    = 378551;
		uint32_t a    = 63689;
		uint64_t hash = 0;

		for(size_t i = 0; i < str.size(); i++)
		{
			hash = hash * a + str[i];
			a    = a * b;
		}
		hash = (hash<<8)+field;
		return hash;
	}
};



inline uint64_t now()
{
	time_t t = time(NULL);
	struct tm ttm;
	localtime_r(&t, &ttm);
	uint64_t ull = 1900;
	ull += ttm.tm_year;
	ull *= 100;
	ull += ttm.tm_mon+1;
	ull *= 100;
	ull += ttm.tm_mday;
	ull *= 100;
	ull += ttm.tm_hour;
	ull *= 100;
	ull += ttm.tm_min;
	ull *= 100;
	ull += ttm.tm_sec;
	return ull;
}

inline uint64_t unow()
{
	timeval tv;
	gettimeofday(&tv, NULL);
	uint64_t t = tv.tv_sec;
	t = t*1000000+tv.tv_usec;
	return t;
}

#define return_on_fail(flag, ret_val) {if (!(flag)) return ret_val;}
#define return_on_fail3(flag, ret_val, cmd) {if (!(flag)){cmd;return ret_val;}}

#define safe_delete(ptr) {if ((ptr) != NULL) delete ptr;}
//x>=flp(x) and flp(x)=pow(2,y)
inline uint32_t flp(uint32_t x)
{
	x=x|(x>>1);
	x=x|(x>>2);
	x=x|(x>>4);
	x=x|(x>>8);
	x=x|(x>>16);
	return x-(x>>1);
}
//x<=clp(x) and clp(x)=pow(2,y)
inline uint32_t clp(uint32_t x)
{
	x=x-1;
	x=x|(x>>1);
	x=x|(x>>2);
	x=x|(x>>4);
	x=x|(x>>8);
	x=x|(x>>16);
	return x+1;
}

template <typename KeyType>
inline KeyType getMinValue()
{
	return 0;
}
template <typename KeyType>
inline KeyType getMaxValue()
{
	return KeyType(-1);
}
template <>
inline int8_t getMinValue<int8_t>()
{
	return -128;
}
template <>
inline int16_t getMinValue<int16_t>()
{
	return -32768;
}
template <>
inline int32_t getMinValue<int32_t>()
{
	return -2147483647-1;
}
template <>
inline int64_t getMinValue<int64_t>()
{
	return  -9223372036854775807ll-1;
}
template <>
inline float getMinValue<float>()
{
	return atof("-inf");
}
template <>
inline double getMinValue<double>()
{
	return atof("-inf");
}

template <>
inline int8_t getMaxValue<int8_t>()
{
	return 127;
}
template <>
inline int16_t getMaxValue<int16_t>()
{
	return 32767;
}
template <>
inline int32_t getMaxValue<int32_t>()
{
	return 2147483647;
}
template <>
inline int64_t getMaxValue<int64_t>()
{
	return  9223372036854775807ll;
}
template <>
inline float getMaxValue<float>()
{
	return atof("inf");
}
template <>
inline double getMaxValue<double>()
{
	return atof("inf");
}


template <typename T>
struct MTObject
{
	volatile T *data[2];
	volatile int count[2];
	volatile int cnode;
	MTObject():cnode(0)
	{
		data[0] = data[1] = NULL;
		count[0] = count[1] = 0;
	}
	~MTObject()
	{
		waitFree(cnode);
		safe_delete(data[cnode]);
	}
	void operator=(T *t)
	{
		set(t);
	}
	T* get()
	{
		__sync_fetch_and_add(&count[cnode], 1);
		return (T*)data[cnode];
	}
	void put(T *t)
	{
		if (t == data[0] )
		{
			__sync_fetch_and_add(&count[0], -1);
			//	tassert(count[0]>=0);
		}
		else if (t == data[1])
		{
			__sync_fetch_and_add(&count[1], -1);
			//		tassert(count[1]>=0);
		}
		else
		{
			assert(0);
		}
	}
	void set(T *t)
	{
		int last_node = cnode;
		int new_node = 1-cnode;
		data[new_node] = t;
		cnode = new_node;

		waitFree(last_node);
		safe_delete(data[last_node]);
		data[last_node] = NULL;
	}
	void waitFree(int n)
	{
		int st = 10;
		while (count[n]>0)
		{
			usleep(st);
			if (st<10000000)
			{
				st+=st;
			}
			else
			{
				assert(0);
			}
		}
	}
};

#endif // UTIL_H_INCLUDED
