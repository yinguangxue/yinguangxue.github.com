#ifndef LOG_H_INCLUDED
#define LOG_H_INCLUDED
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "Io.h"
//#include "util.h"
//#include "StringSplitter.h"
//#include "path.h"
//#define DEBUG 1

enum LOG_Group
{
	LOG_CLIENT,
	LOG_SERVER,
	LOG_UPDATE,
	LOG_SEARCH,
	LOG_IDSERVER,
	LOG_INVALIDPOI,
	LOG_DEBUG,
	LOG_CRITICAL,
	LOG_ERROR,
	LOG_WARNING,
	INFO,
	LOG_SIZE
};

const static char *LOG_Group_Str[20] =
{
	"LOG_CLIENT",
	"LOG_SERVER",
	"LOG_UPDATE",
	"LOG_SEARCH",
	"LOG_IDSERVER",
	"LOG_INVALIDPOI",
	"LOG_DEBUG",
	"LOG_CRITICAL",
	"LOG_ERROR",
	"LOG_WARNING",
	"INFO",
	"LOG_SIZE"
};

enum LOG_Status
{
	LOG_STATUS_NOLOG = 0,
	LOG_STATUS_FILE = 1,
	LOG_STATUS_STDOUT = 2,
	LOG_STATUS_STDERR = 4
};

class Logger
{
protected:
	FILE *fp;
	string path;
	Lock  l;
	int log_status;

public:
	static Logger *  Instance()
	{
		static Logger   log;
		return &log;
	}

	virtual ~Logger()
	{
		if (fp != NULL)
			fclose(fp);
	}
	void setStatus(int status)
	{
		log_status = status;
	}
	virtual void checkFile(uint64_t cur_time)
	{
		if (fp == NULL)
		{
			//fp = fopen(pathjoin(path, "log").c_str(), "a");
			char buf[256];
#if __WORDSIZE == 64
			snprintf(buf, 256, "%s/%lu", path.c_str(), cur_time/1000000);
#else
			snprintf(buf, 256, "%s/%llu", path.c_str(), cur_time/1000000);
#endif
			fp = fopen(buf, "a");
		}
	}

	void log(LOG_Group group, const string& str)
	{
		log(group, str.c_str());
	}
	void log(LOG_Group group, const char *str)
	{
		uint64_t cur_time = now();
		l.lock();
		if (log_status & LOG_STATUS_FILE)
		{
			checkFile(cur_time);
			printlog(fp, cur_time, group, str);
		}
		/*#ifdef DEBUG
		if (log_status & LOG_STATUS_STDOUT)
		{
			printlog(stdout, cur_time, group, str);
		}
		
		if (log_status & LOG_STATUS_STDERR)
		{
			printlog(stderr, cur_time, group, str);
		}*/
		l.unlock();
	}
	void printlog(FILE* fp, uint64_t cur_time, LOG_Group group, const char *str)
	{
		if (str==NULL) return;
		if (str[strlen(str)-1]=='\n')
		{
#if __WORDSIZE == 64
		fprintf(fp, "%lu\t%s\t%s", cur_time, LOG_Group_Str[group], str);
#else
		fprintf(fp, "%llu\t%s\t%s", cur_time, LOG_Group_Str[group], str);
#endif
		}
		else
		{
#if __WORDSIZE == 64
		fprintf(fp, "%lu\t%s\t%s\n", cur_time, LOG_Group_Str[group], str);
#else
		fprintf(fp, "%llu\t%s\t%s\n", cur_time, LOG_Group_Str[group], str);
#endif
		}
		fflush(fp);
	}

protected:
	Logger():fp(NULL), path("./log"), log_status(LOG_STATUS_FILE)
	{
	}
	Logger(const string& ipath, int istatus = LOG_STATUS_FILE): fp(NULL), path(ipath), log_status(istatus)
	{
		/*const char *dir = path.c_str();
		if (mkdir(dir, 0777) == -1)
		{
		}*/
	}
};


inline void log(LOG_Group group, const char *str)
{
	Logger::Instance()->log(group, str);
}

inline void log(LOG_Group group, const string& str)
{
	Logger::Instance()->log(group, str.c_str());
}

/*#ifdef DEBUG
#define Debug(s) log(LOG_DEBUG, s)
#define DEBUG_START() if (1){
#define DEBUG_END() }
#else
#define Debug(s) {}
#define DEBUG_START() if (0){
#define DEBUG_END() }
#endif
*/
#endif // LOG_H_INCLUDED

