#ifndef	 IO_H
#define	 IO_H

#include <unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include <pthread.h>
#include "util.h"
#include "Serialize.h"
#include "StringSplitter.h"
#include "Thread.h"
#include <sys/mman.h>

#define FILE_BUF_SIZE off_t(65536)


/*template <typename T>
class ssingleton
{
protected:
	struct object_creator
	{
		object_creator() 
		{
			ssingleton<T>::instance(); 
		}
		inline void do_nothing() const { }
	};

	static object_creator create_object;

	ssingleton(){};

public:
	typedef T object_type;
	static object_type & instance()
	{
		static object_type obj;
		create_object.do_nothing();
		return obj;
	}

	static object_type& getInstance()
	{
		return instance();
	}
};

template <typename T>
typename ssingleton<T>::object_creator ssingleton<T>::create_object;

class RWLock
{
	pthread_rwlock_t mutex;
public:
	RWLock()
	{
		pthread_rwlock_init(&mutex, NULL);
	}
	~RWLock()
	{
		pthread_rwlock_destroy(&mutex);
	}
	void rlock()
	{
		pthread_rwlock_rdlock(&mutex);
	}
	void wlock()
	{
		pthread_rwlock_wrlock(&mutex);
	}
	void unlock()
	{
		pthread_rwlock_unlock(&mutex);
	}
};


class Lock
{
	pthread_mutex_t mutex;
public:
	Lock()
	{
		init(false);
	}
	~Lock()
	{
		destroy();
	}
	void init(bool ipc)
	{
		if (ipc)
		{
			pthread_mutexattr_t attr;
			pthread_mutexattr_init(&attr);
			pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
			pthread_mutex_init(&mutex, &attr);
			pthread_mutexattr_destroy(&attr);
		}
		else
		{
			pthread_mutex_init(&mutex, NULL);
		}
	}
	void destroy()
	{
		pthread_mutex_destroy(&mutex);
	}
	void lock()
	{
		pthread_mutex_lock(&mutex);
	}
	void unlock()
	{
		pthread_mutex_unlock(&mutex);
	}
};
*/


struct FileLocker: public ssingleton<FileLocker>
{
	RWLock lock;
};

class FileReader
{
	int fd;
	char buf[FILE_BUF_SIZE];
	size_t pos, bsize;
	off_t rp;
	struct stat stbuf;
	off_t reread()
	{
		off_t n = min(stbuf.st_size-rp, FILE_BUF_SIZE);
		if (n == 0) return 0;
		FileLocker::instance().lock.rlock();
		off_t ret = safe_read(fd, buf, n);
		assert(ret == n);
		pos = 0;
		rp+=n;
		bsize = n;
		FileLocker::instance().lock.unlock();
		return n;
	}

	inline int32_t safe_read(int fd, void* buf, uint32_t size)
	{
		int32_t cc;
		uint32_t sz = size;
		char* bp =(char *) buf;
		do
		{
			cc = ::read(fd, bp,(size_t)sz);
			if( cc > 0 ) 
			{
				bp += cc;
				sz -= cc;
			} 
			else if( cc==0 )	// EOF
			{
				return (sz) ? (size-sz) : 0;
			}
			else if( cc < 0)
			{
				cout<<"error read:";
				return cc;
			}
		} while (sz > 0);
		return size;
	}

public:
	FileReader(const FileReader& fr):pos(fr.pos), bsize(fr.bsize), rp(fr.rp), stbuf(fr.stbuf)
	{
		memcpy(buf, fr.buf, pos);
		fd = dup(fr.fd);
	}
	FileReader(const string& path):pos(0), bsize(0), rp(0)
	{
		fd = open(path.c_str(), O_RDONLY);
		if (fd == -1)
		{
			perror(pack_string("open file %s error:", path.c_str()).c_str());
		}
		if (fstat(fd, &stbuf) == -1) stbuf.st_size=0;
	}
	FileReader(int ifd):pos(0), bsize(0), rp(0)
	{
		fd = ifd;
		if (fstat(fd, &stbuf) == -1) stbuf.st_size=0;
	}
	~FileReader()
	{
		close(fd);
	}
	FileReader& operator=(const FileReader& fr)
	{
		pos=fr.pos;
		rp=fr.rp;
		bsize=fr.bsize;
		stbuf=fr.stbuf;
		memcpy(buf, fr.buf, pos);
		fd = dup(fr.fd);
		return *this;
	}
	off_t getPos()
	{
		return rp-bsize+pos;
	}
	off_t size()
	{
		return stbuf.st_size;
	}
	
	off_t read(void *data, size_t len)
	{
		size_t ret = 0;
		while (len>ret+bsize-pos)
		{
			size_t n = bsize-pos;
			memcpy((char *)data+ret, buf+pos, n);
			ret+=n;
			if (reread() == 0) return ret;
		}
		memcpy((char *)data+ret, buf+pos, len-ret);
		pos+=len-ret;
		ret=len;
		return ret;
	}
	off_t pread(off_t offset, void *data, size_t len)
	{
		return ::pread(fd, data, len, offset);
	}

	/*void* mmap(off_t offset, size_t len)
	{
		if (len == 0) return NULL;
		size_t page_off = offset%getpagesize();
		FileLocker::instance().lock.rlock();
		void *ret = ::mmap(NULL, len+page_off, PROT_READ, MAP_SHARED, fd, offset-page_off);
		if (ret == (void *)-1)
		{
			perror("");
			assert(0);
		}
		FileLocker::instance().lock.unlock();
		return (char *)ret+page_off;
	}

	void munmap(void *data, size_t len)
	{
		if (data == NULL) return;
		size_t page_off = (size_t)data%getpagesize();
		if (::munmap((char *)data-page_off, len+page_off) == -1)
		{
			perror("");
			assert(0);
		}
	}
	*/

	bool isValid()
	{
		return fd != -1;
	}
};

class FileWriter
{
	int fd;
	char buf[FILE_BUF_SIZE];
	size_t pos;
	off_t wlen;
public:
	FileWriter(FileWriter& fw)
	{
		fw.flush();
		fd = dup(fw.fd);
		pos = 0;
		wlen = fw.wlen;
	}
	FileWriter(const string& path, bool trunc=true):pos(0), wlen(0)
	{
		fd = open(path.c_str(), O_WRONLY|O_CREAT|O_EXCL, 0644);
		if (fd == -1 && errno == EEXIST)
		{
			fd = open(path.c_str(), O_WRONLY|(trunc?O_TRUNC:O_APPEND), 0644);
		}
		if (fd == -1)
		{
			perror("open file error:");
		}
		struct stat st_buf;
		if (fstat(fd, &st_buf) != -1)
		{
			wlen = st_buf.st_size;
			lseek(fd, 0, SEEK_END);
		}
	}
	FileWriter(int ifd):fd(ifd), pos(0), wlen(0)
	{
		struct stat st_buf;
		if (fstat(fd, &st_buf) != -1)
		{
			wlen = st_buf.st_size;
			lseek(fd, 0, SEEK_END);
		}
	}
	~FileWriter()
	{
		flush();
		close(fd);
	}
	FileWriter& operator=(FileWriter& fw)
	{
		fw.flush();
		fd = dup(fw.fd);
		pos = 0;
		wlen = fw.wlen;
		return *this;
	}
	off_t size()
	{
		return wlen+pos;
	}
	off_t getPos()
	{
		return wlen+pos;
	}
	void flush()
	{
		FileLocker::instance().lock.wlock();
		assert(safe_write(fd, buf, pos) == (off_t)pos);
		FileLocker::instance().lock.unlock();
		wlen += pos;
		pos = 0;
	}
	off_t write(const void *data, size_t len)
	{
		off_t ret = 0;
		while (len > ret+FILE_BUF_SIZE-pos)
		{
			size_t n = FILE_BUF_SIZE-pos;
			memcpy(buf+pos, (const char *)data+ret, n);
			pos+=n;
			flush();
			ret+=n;
		}
		memcpy(buf+pos, (const char *)data+ret, len-ret);
		pos+=len-ret;
		ret=len;
		return ret;
	}
	off_t pwrite(off_t offset, const void *data, off_t len)
	{
		assert(offset+len<=getPos());
		if (offset<wlen && offset+len>wlen)
		{
			flush();
		}
		if (offset>=wlen)
		{
			memcpy(buf+offset-wlen, data, len);
			return len;
		}
		else if (offset+len>wlen)
		{
			memcpy(buf, (const char*)data+(wlen-offset), offset+len-wlen);
			return ::pwrite(fd, data, wlen-offset, offset);
		}
		else
		{
			return ::pwrite(fd, data, len, offset);
		}
	}
	off_t write(const string& s)
	{
		return write(s.c_str(), s.size());
	}
	off_t pwrite(off_t offset, const string& s)
	{
		return pwrite(offset, s.c_str(), s.size());
	}

	inline int32_t safe_write(int fd, const void* buf, uint32_t size, int flag = 0)
	{
		int32_t cc;
		uint32_t sz = size;
		const char *bp = (const char *)buf;
		if( size==0 )	return 0;
		do 
		{
			cc = ::write(fd, bp, (size_t)sz); //linux д�ļ�
			if( cc > 0 )
			{
				bp += cc;
				sz -= cc;
			}
			else if( cc < 0 && errno != EINTR && errno != EAGAIN && errno != EWOULDBLOCK)
			{
				return cc;
			}
		} while (sz > 0);
		return size;
	}

	bool isValid()
	{
		return fd != -1;
	}
};

template <>
class SerializeImp<FileWriter>:public Serialize
{
public:
	FileWriter& fd;
	SerializeImp(FileWriter &ifd):fd(ifd)
	{
	}
	virtual void operator()(const void *buf, size_t len)
	{
		assert(fd.write(buf, len) == (off_t)len);
	}
	bool isValid()
	{
		return fd.isValid();
	}
};
template <>
class UnSerializeImp<FileReader>:public UnSerialize
{
public:
	FileReader& fd;
	UnSerializeImp(FileReader &ifd):fd(ifd)
	{
	}
	virtual void operator()(void *buf, size_t len)
	{
		assert(fd.read(buf, len) == (off_t)len);
	}
	bool isValid()
	{
		return fd.isValid();
	}
};

class FileSerialize:public Serialize //fileserialize -> file_write.
{
	FileWriter fw;
public:
	FileSerialize(const string& path, bool trunc=true):fw(path, trunc)
	{
		s = new SerializeImp<FileWriter>(fw);
	}
	off_t size()
	{
		return fw.size();
	}
};

class FileUnSerialize:public UnSerialize
{
	FileReader fr;
public:
	FileUnSerialize(const string& path):fr(path)
	{
		s = new UnSerializeImp<FileReader>(fr);
	}
};
#endif // IO_H_INCLUDED
