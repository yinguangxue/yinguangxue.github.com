#ifndef  CONFIGREADER_H
#define CONFIGREADER_H
#include <string>
#include <iostream>
#include <map>
#include <vector>
#include "StringSplitter.h"
//#include "log.h"

using namespace std;

class ConfigReader
{
public:
	ConfigReader(bool ignore_empty = true) {}
	ConfigReader(const string& file, bool ignore_empty = true)
	{
		operator()(file, ignore_empty);
	}
	ConfigReader(const map<string, string>& imap):cmap(imap) { }
	map<string, string> operator()(string file, bool ignore_empty = true)
	{
		cmap.clear();
		ifstream in(file.c_str());
		if (!in.good()) return cmap;
		string line;
		while (getline(in, line))
		{
			strip(line);
			if (line.empty() || line[0] == '#') continue;
			vector<string> kp;
			size_t pos = line.find('=');
			if (pos == string::npos)
			{
				continue;
			}
			string key = line.substr(0, pos);
			string value = line.substr(pos+1, line.size()-pos-1);
			strip(key);
			strip(value);
			if (ignore_empty && value.empty()) continue;
			cmap[key] = value;
		}
		return cmap;
	}

	template <typename T>
	void set(T& value, const string& name, const T& default_value)
	{
		set(name, value, default_value);
	}
	template <typename T>
	void set(const string& name, T& value, const T& default_value)
	{
		value = default_value;
		vector<string> vs = strsplit(name, '|');
		vs.push_back(name);
		for (size_t i=0; i<vs.size(); i++)
		{
			if (cmap.count(vs[i]))
			{
				value = str2num<T>(cmap[vs[i]]);
			}
		}
	}

	void set(string& value, const string& name, const char* default_value)
	{
		set(name, value, default_value);
	}

	void set(const string& name, string& value, const char* default_value)
	{
		value = default_value;
		vector<string> vs = strsplit(name, '|');
		vs.push_back(name);
		for (size_t i=0; i<vs.size(); i++)
		{
			if (cmap.count(vs[i]))
			{
				value = cmap[vs[i]];
			}
		}
		if (value == "\\t") value = "\t";
	}

	void set(const string& name, vector<string>& value, const char split_char)
	{
		value.clear();
		vector<string> vs = strsplit(name, '|');
		vs.push_back(name);
		for (size_t i=0; i<vs.size(); i++)
		{
			if (cmap.count(vs[i]))
			{
				StringSplitter()(value, cmap[vs[i]], split_char);
			}
		}
	}

	string operator[](const string& s)
	{
		return cmap[s];
	}
	size_t count(const string& s)
	{
		return cmap.count(s);
	}
	void removeEmptyValues()
	{
		vector<string> ekeys;
		for (map<string, string>::iterator it = cmap.begin(); it != cmap.end(); ++it)
		{
			if (it->second.empty()) ekeys.push_back(it->first);
		}
		for (size_t i=0; i<ekeys.size(); i++)
			cmap.erase(ekeys[i]);
	}

	/*void getkeyvalue(map<string, string>& map)
	{
	    map<string, string>::iterator itr;
	    for(itr = cmap.begin(); itr != cmap.end(); itr++)
	    {
		map.insert(make_pair(itr->first, itr->second));
	    }
	}*/


private:
	void strip(string& s) const
	{
		uint32_t i, j;
		for (i=0; i<s.size() && s[i] == ' '; i++);
		for (j=s.size(); j>0 && s[j-1] ==' '; j--);
		s = s.substr(i, j-i);
	}
	map<string, string> cmap;
};

#endif // CONFIGREADER_H_INCLUDED
