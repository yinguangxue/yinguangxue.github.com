#ifndef  TIMER_H
#define TIMER_H
#include <iostream>
using namespace std;
#include <time.h>
#include <sys/time.h>

class Timer
{
	struct timeval t1, t2;
public:
	Timer()
	{
		Time();
	}
	void Time()
	{
		t1 = t2;
		gettimeofday(&t2, NULL);
	}
	double  IntervalTime()
	{
		Time();
		return (t2.tv_sec-t1.tv_sec)*1000+(t2.tv_usec-t1.tv_usec)/1000.0; //ms
	}

	int interval()
	{
		return (t2.tv_sec-t1.tv_sec)*1000000+t2.tv_usec-t1.tv_usec;
	}

	void print(const char *str = "")
	{
		cout << "Time is "<<interval()<<"us: "<<str<<endl;
	}
	void time(const char *str)
	{
		Time();
		print(str);
	}
};
#ifdef DEBUG
typedef Timer DTimer;
#else
class DTimer
{
public:
	DTimer()
	{
	}
	void time()
	{
	}
	int interval()
	{
		return 0;
	}
	void print(const char *str = "")
	{
	}
	void time(const char *str)
	{
	}
};
#endif


#endif // TIMER_H_INCLUDED
