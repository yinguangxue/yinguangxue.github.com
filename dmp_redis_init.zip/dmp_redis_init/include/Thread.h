#ifndef THREAD_H_
#define THREAD_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <setjmp.h>
#include "util.h"
#include "Timer.h"


class FakeLock
{
public:
	void init(bool ipc){}
	void destroy(){}
	void lock(){}
	void rlock(){}
	void wlock(){}
	void unlock(){}
};
#ifdef SINGLE_THREAD_MODE
typedef FakeLock SpinLock;
typedef FakeLock Lock;
typedef FakeLock RWLock;
#else
class Lock
{
	pthread_mutex_t mutex;
public:
	Lock()
	{
		init(false);
	}
	~Lock()
	{
		destroy();
	}
	void init(bool ipc)
	{
		if (ipc)
		{
			pthread_mutexattr_t attr;
			pthread_mutexattr_init(&attr);
			pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
			pthread_mutex_init(&mutex, &attr);
			pthread_mutexattr_destroy(&attr);
		}
		else
		{
			pthread_mutex_init(&mutex, NULL);
		}
	}
	void destroy()
	{
		pthread_mutex_destroy(&mutex);
	}
	void lock()
	{
		pthread_mutex_lock(&mutex);
	}
	void unlock()
	{
		pthread_mutex_unlock(&mutex);
	}
};


class RWLock
{
	pthread_rwlock_t mutex;
public:
	RWLock()
	{
		pthread_rwlock_init(&mutex, NULL);
	}
	~RWLock()
	{
		pthread_rwlock_destroy(&mutex);
	}
	void rlock()
	{
		pthread_rwlock_rdlock(&mutex);
	}
	void wlock()
	{
		pthread_rwlock_wrlock(&mutex);
	}
	void unlock()
	{
		pthread_rwlock_unlock(&mutex);
	}
};
inline bool operator==(const RWLock& l1, const RWLock& l2)
{
	return memcmp(&l1, &l2, sizeof(l1)) == 0;
}
class SpinLock
{
	pthread_spinlock_t sp;
public:
	SpinLock()
	{
		pthread_spin_init(&sp, PTHREAD_PROCESS_PRIVATE);
	}
	~SpinLock()
	{
		pthread_spin_destroy(&sp);
	}
	void lock()
	{
		pthread_spin_lock(&sp);
	}
	void unlock()
	{
		pthread_spin_unlock(&sp);
	}
};
class Condition
{
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	Lock l;
public:
	Condition()
	{
		pthread_mutex_init(&mutex, NULL);
		pthread_cond_init(&cond, NULL);
		l.lock();
	}
	~Condition()
	{
		pthread_mutex_destroy(&mutex);
		pthread_cond_destroy(&cond);
		l.unlock();
	}
	void wait()
	{
		pthread_mutex_lock(&mutex);
		l.unlock();
		pthread_cond_wait(&cond, &mutex);
		pthread_mutex_unlock(&mutex);
	}
	void signal()
	{
		l.lock();
		pthread_mutex_lock(&mutex);
		pthread_cond_signal(&cond);
		pthread_mutex_unlock(&mutex);

	}
};
#endif
void *ThreadFunc(void *args);
#include <setjmp.h>
class Thread
{
protected:
	pthread_t tid;
	bool is_running;
	jmp_buf jbuf;
	bool first_run;
public:
	Thread():tid(0),is_running(false),first_run(true)
	{
	}
	virtual ~Thread()
	{
	}
	void start()
	{
		is_running = true;
		if (pthread_create(&tid, NULL, ThreadFunc, this) != 0)
		{
			perror("create thread error!");
			std::cout<<"create thread fail!"<<std::endl;
			exit(1);
		}
	}
	virtual void run() = 0;
	virtual void stop()
	{
		is_running = false;
	}
	void runThread()
	{
		first_run = true;
		/*setjmp(jbuf);
		if (first_run)
		{
			first_run = false;
			run();
		}*/
		run();
	}
	void join()
	{
		pthread_join(tid, NULL);
	}
	bool tryJoin()
	{
		int ret = pthread_tryjoin_np(tid, NULL);
		if (ret == 0) return true;
		return false;
	}
	void set_running()
	{
		is_running = true;
	}
	void exitThread()
	{
		longjmp(jbuf, 1);
	}
};
template <typename T>
class ssingleton
{
protected:
	struct object_creator
	{
		object_creator() { ssingleton<T>::instance(); }
		inline void do_nothing() const { }
	};
	static object_creator create_object;
	ssingleton(){};
public:
	typedef T object_type;
	static object_type & instance()
	{
		static object_type obj;
		create_object.do_nothing();
		return obj;
	}
	static object_type& getInstance()
	{
		return instance();
	}
};
template <typename T>
typename ssingleton<T>::object_creator ssingleton<T>::create_object;
class Threads:public ssingleton<Threads>
{
	map<pthread_t, Thread*> threads;
	Lock l;
public:
	Threads()
	{
	}
	void registerThread(Thread *t)
	{
		l.lock();
		threads[pthread_self()] = (Thread *)t;
		l.unlock();
	}
	void unregisterThread(Thread *t)
	{
		l.lock();
		threads.erase(pthread_self());
		l.unlock();
	}
	map<pthread_t, Thread*> getThreads()
	{
		return threads;
	}
	Thread* getThread(pthread_t tid = pthread_self())
	{
		Thread* t = NULL;
		l.lock();
		if (threads.count(tid)) t = threads[tid];
		l.unlock();
		return t;
	}
};
inline void *ThreadFunc(void *args)
{
	Thread *t = (Thread*)args;
	Threads::instance().registerThread(t);
	t->runThread();
	Threads::instance().unregisterThread(t);
	return NULL;
}
#endif
