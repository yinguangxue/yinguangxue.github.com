#include "json.h"
#include <stdio.h>
#include "thirdparty/gtest/gtest.h"
TEST(JsonWriterTest, JsonWrite) {
  Json::Value root;
  Json::Value arrayObj;
  Json::Value item;
  for (int i = 0; i < 10; i++) {
    item["key"] = i;
    root["array"].append(item);
  }
  root["key1"] = "val1";
  std::string out = root.toStyledString();
  std::cout << out << std::endl;
}
